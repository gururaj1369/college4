
<?php include 'header.php'; ?>

	
          <style>


 .example-image-link{ padding:5px 10px; border:1px solid #ddd;	 background:#efeef; display:block;}

  .widget-event .date .day {
    background-color: #0102d9;
    color: #ffffff;
    font-size: 24px;


}

p{
  text-align:justify;
}

.img-responsive,
.thumbnail > img,
.thumbnail a > img,
.carousel-inner > .item > img,
.carousel-inner > .item > a > img {
  display: block;
  max-width: 100%;
  height: auto;
}
</style>

     <div class="page-title" style="background-color: rgb(1 2 217); ">
			<div class="grid-row">
				<h1 style="color: #000;">Reconstitute anti ragging Committee
</h1>
				<nav class="bread-crumb">
					<a href="/">Home</a>
					<i class="fas fa-long-arrow-alt-right"></i>
				
					<a href="anti-ragging.php">Reconstitute anti ragging Committee

</a>
				</nav>
			</div>
		</div>



<div class="row page-content grid-row">
    <main>
      <div class="grid-col-row clear-fix">
        
        
      



        
        <div class="grid-col grid-col-3">
          <div class="portfolio-item">
            <div class="picture">
              <div class="hover-effect"></div>
              <div class="link-cont">
              
                <a href="index_files/arc/prinipal.jpg" class="fancy fa fa-search"></a>
                
              </div>
              <img style="width:100%;height:260px" src="index_files/arc/prinipal.jpg" data-at2x="/uploads/2401/661243/prinipal.jpg" alt="">
            </div>
            <h3>Dr. P. Sampath Rao (Principal)</h3>
            <p>Chairman</p>
            <p>9505518271</p>
          </div>
          
        </div>
        



        
        <div class="grid-col grid-col-3">
          <div class="portfolio-item">
            <div class="picture">
              <div class="hover-effect"></div>
              <div class="link-cont">
              
                <a href="index_files/arc/patil.png" class="fancy fa fa-search"></a>
                
              </div>
              <img style="width:100%;height:260px" src="index_files/arc/patil.png" data-at2x="/uploads/2401/661244/patil.png" alt="">
            </div>
            <h3>Mr.Prakash Patil , (HOD) (Department of ECE)</h3>
            <p>Member</p>
            <p>9848653323</p>
          </div>
          
        </div>
        



        
        <div class="grid-col grid-col-3">
          <div class="portfolio-item">
            <div class="picture">
              <div class="hover-effect"></div>
              <div class="link-cont">
              
                <a href="index_files/arc/swapna.png" class="fancy fa fa-search"></a>
                
              </div>
              <img style="width:100%;height:260px" src="index_files/arc/swapna.png" data-at2x="/uploads/2401/661245/swapna.png" alt="">
            </div>
            <h3>Mrs. A. Swapna Assistant Professor)</h3>
            <p>Member</p>
            <p>9701661445</p>
          </div>
          
        </div>
        



        
        <div class="grid-col grid-col-3">
          <div class="portfolio-item">
            <div class="picture">
              <div class="hover-effect"></div>
              <div class="link-cont">
              
                <a href="index_files/arc/t_shrujan.jpg" class="fancy fa fa-search"></a>
                
              </div>
              <img style="width:100%;height:260px" src="index_files/arc/t_shrujan.jpg" data-at2x="/uploads/2401/661246/t_shrujan.jpg" alt="">
            </div>
            <h3>Mr. T. Srujan Kumar(HOD) <br>  (Department of Civil Engieeering)  </h3>
            <p>Member</p>
            <p>6281732809</p>
          </div>
          
        </div>
        



        
        <div class="grid-col grid-col-3">
          <div class="portfolio-item">
            <div class="picture">
              <div class="hover-effect"></div>
              <div class="link-cont">
              
                <a href="index_files/arc/shiva_kumar.jpg" class="fancy fa fa-search"></a>
                
              </div>
              <img style="width:100%;height:260px" src="index_files/arc/shiva_kumar.jpg" data-at2x="/uploads/2401/661247/shiva_kumar.jpg" alt="">
            </div>
            <h3>Mr. P. Shiva Kumar(HOD)<br>  Department of Mechanical Engineering </h3>
            <p>Member</p>
            <p>6281505609</p>
          </div>
          
        </div>
        



        
        <div class="grid-col grid-col-3">
          <div class="portfolio-item">
            <div class="picture">
              <div class="hover-effect"></div>
              <div class="link-cont">
              
                <a href="index_files/arc/samya.jpg" class="fancy fa fa-search"></a>
                
              </div>
              <img style="width:100%;height:260px" src="index_files/arc/samya.jpg" data-at2x="/uploads/2401/661248/samya.jpg" alt="">
            </div>
            <h3>Mr. B. Samya (HOD) <br> Department of CSE</h3>
            <p>Member</p>
            <p>9848868031</p>
          </div>
          
        </div>
        



        
        <div class="grid-col grid-col-3">
          <div class="portfolio-item">
            <div class="picture">
              <div class="hover-effect"></div>
              <div class="link-cont">
              
                <a href="index_files/arc/rathod.png" class="fancy fa fa-search"></a>
                
              </div>
              <img style="width:100%;height:260px" src="index_files/arc/rathod.png" data-at2x="/uploads/2401/661249/rathod.png" alt="">
            </div>
            <h3>Mr. Subhash Rathod (HOD) <br> Department of EEE</h3>
            <p>Member</p>
            <p>9491746466</p>
          </div>
          
        </div>
        



        
        <div class="grid-col grid-col-3">
          <div class="portfolio-item">
            <div class="picture">
              <div class="hover-effect"></div>
              <div class="link-cont">
              
                <a href="index_files/arc/mohan.jpg" class="fancy fa fa-search"></a>
                
              </div>
              <img style="width:100%;height:260px" src="index_files/arc/mohan.jpg" data-at2x="/uploads/2401/662362/mohan.jpg" alt="">
            </div>
            <h3>B.Mohan Vice-principal Polytechnic</h3>
            <p>Member</p>
            <p>9949207789</p>
          </div>
          
        </div>
        



        
        <div class="grid-col grid-col-3">
          <div class="portfolio-item">
            <div class="picture">
              <div class="hover-effect"></div>
              <div class="link-cont">
              
                <a href="index_files/arc/men.png" class="fancy fa fa-search"></a>
                
              </div>
              <img style="width:100%;height:260px" src="index_files/arc/men.png" data-at2x="/uploads/2401/661271/men.png" alt="">
            </div>
            <h3>R.kalyan representatives of students belonging to the fresher’s category as well as senior students</h3>
            <p>Member</p>
            <p>9640849821</p>
          </div>
          
        </div>
        



        
        <div class="grid-col grid-col-3">
          <div class="portfolio-item">
            <div class="picture">
              <div class="hover-effect"></div>
              <div class="link-cont">
              
                <a href="index_files/arc/Rajitha.png" class="fancy fa fa-search"></a>
                
              </div>
              <img style="width:100%;height:260px" src="index_files/arc/Rajitha.png" data-at2x="/uploads/2401/661251/Rajitha.png" alt="">
            </div>
            <h3>A.Rajitha (Asst.professor)</h3>
            <p>Member</p>
            <p>9885703011</p>
          </div>
          
        </div>
        



        
        <div class="grid-col grid-col-3">
          <div class="portfolio-item">
            <div class="picture">
              <div class="hover-effect"></div>
              <div class="link-cont">
              
                <a href="index_files/arc/sandeep.png" class="fancy fa fa-search"></a>
                
              </div>
              <img style="width:100%;height:260px" src="index_files/arc/sandeep.png" data-at2x="/uploads/2401/661252/sandeep.png" alt="">
            </div>
            <h3>K.Sandeep (Asst.professor)</h3>
            <p>Member</p>
            <p>9494712702</p>
          </div>
          
        </div>
        



        
        <div class="grid-col grid-col-3">
          <div class="portfolio-item">
            <div class="picture">
              <div class="hover-effect"></div>
              <div class="link-cont">
              
                <a href="index_files/arc/chetan.png" class="fancy fa fa-search"></a>
                
              </div>
              <img style="width:100%;height:260px" src="index_files/arc/chetan.png" data-at2x="/uploads/2401/661253/chetan.png" alt="">
            </div>
            <h3>K.Chetan (sr.lecturer)</h3>
            <p>Member</p>
            <p>9494651610</p>
          </div>
          
        </div>
        



        
        <div class="grid-col grid-col-3">
          <div class="portfolio-item">
            <div class="picture">
              <div class="hover-effect"></div>
              <div class="link-cont">
              
                <a href="index_files/arc/t.Saritha.png" class="fancy fa fa-search"></a>
                
              </div>
              <img style="width:100%;height:260px" src="index_files/arc/t.Saritha.png" data-at2x="/uploads/2401/661254/t.Saritha.png" alt="">
            </div>
            <h3>T.SARITHA (SR. lecturer)</h3>
            <p>Member</p>
            <p>7997448020</p>
          </div>
          
        </div>
        



        
        <div class="grid-col grid-col-3">
          <div class="portfolio-item">
            <div class="picture">
              <div class="hover-effect"></div>
              <div class="link-cont">
              
                <a href="index_files/arc/lingareddy.png" class="fancy fa fa-search"></a>
                
              </div>
              <img style="width:100%;height:260px" src="index_files/arc/lingareddy.png" data-at2x="/uploads/2401/661255/lingareddy.png" alt="">
            </div>
            <h3>K.LINGAREDDY representatives of students belonging to the senior students</h3>
            <p>Member</p>
            <p>9603004172</p>
          </div>
          
        </div>
        



        
        <div class="grid-col grid-col-3">
          <div class="portfolio-item">
            <div class="picture">
              <div class="hover-effect"></div>
              <div class="link-cont">
              
                <a href="index_files/arc/lothitha.png" class="fancy fa fa-search"></a>
                
              </div>
              <img style="width:100%;height:260px" src="index_files/arc/lothitha.png" data-at2x="/uploads/2401/661256/lothitha.png" alt="">
            </div>
            <h3>K.Lohitha representatives of students belonging to the fresher’s category as well as senior students</h3>
            <p>Member</p>
            <p>7330607941</p>
          </div>
          
        </div>
        



        
        <div class="grid-col grid-col-3">
          <div class="portfolio-item">
            <div class="picture">
              <div class="hover-effect"></div>
              <div class="link-cont">
              
                <a href="index_files/arc/sudha.png" class="fancy fa fa-search"></a>
                
              </div>
              <img style="width:100%;height:260px" src="index_files/arc/sudha.png" data-at2x="/uploads/2401/661257/sudha.png" alt="">
            </div>
            <h3> S.SUDHA representatives of students belonging to the senior students Screen reader support enabled.            S.SUDHA representatives of students belonging to the senior students</h3>
            <p>Member</p>
            <p>9014761968</p>
          </div>
          
        </div>
        



        
        <div class="grid-col grid-col-3">
          <div class="portfolio-item">
            <div class="picture">
              <div class="hover-effect"></div>
              <div class="link-cont">
              
                <a href="index_files/arc/sai_kumar.png" class="fancy fa fa-search"></a>
                
              </div>
              <img style="width:100%;height:260px" src="index_files/arc/sai_kumar.png" data-at2x="/uploads/2401/661258/sai_kumar.png" alt="">
            </div>
            <h3>Sai kumar local media</h3>
            <p>Member</p>
            <p>964036595</p>
          </div>
          
        </div>
        



        
        <div class="grid-col grid-col-3">
          <div class="portfolio-item">
            <div class="picture">
              <div class="hover-effect"></div>
              <div class="link-cont">
              
                <a href="index_files/arc/men.png" class="fancy fa fa-search"></a>
                
              </div>
              <img style="width:100%;height:260px" src="index_files/arc/men.png" data-at2x="/uploads/2401/661272/men.png" alt="">
            </div>
            <h3>SI makloor civil and administration</h3>
            <p>Member</p>
            <p>9440795438</p>
          </div>
          
        </div>
        



        
        <div class="grid-col grid-col-3">
          <div class="portfolio-item">
            <div class="picture">
              <div class="hover-effect"></div>
              <div class="link-cont">
              
                <a href="index_files/arc/men.png" class="fancy fa fa-search"></a>
                
              </div>
              <img style="width:100%;height:260px" src="index_files/arc/men.png" data-at2x="/uploads/2401/661273/men.png" alt="">
            </div>
            <h3>N.pramod civil and police administration</h3>
            <p>Member</p>
            <p>9848681400</p>
          </div>
          
        </div>
        



        
        <div class="grid-col grid-col-3">
          <div class="portfolio-item">
            <div class="picture">
              <div class="hover-effect"></div>
              <div class="link-cont">
              
                <a href="index_files/arc/rajkumar.png" class="fancy fa fa-search"></a>
                
              </div>
              <img style="width:100%;height:260px" src="index_files/arc/rajkumar.png" data-at2x="/uploads/2401/661259/rajkumar.png" alt="">
            </div>
            <h3>U.Rajkumar</h3>
            <p>Member</p>
            <p>9848868036</p>
          </div>
          
        </div>
        
        
        
      
      </div>
    
    </main>
  </div>



<?php include 'footer.php'; ?>