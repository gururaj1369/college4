
<?php include 'header.php'; ?>

	
          <style>


 .example-image-link{ padding:5px 10px; border:1px solid #ddd;	 background:#efeef; display:block;}

  .widget-event .date .day {
    background-color: #0102d9;
    color: #ffffff;
    font-size: 24px;


}

p{
  text-align:justify;
}

.img-responsive,
.thumbnail > img,
.thumbnail a > img,
.carousel-inner > .item > img,
.carousel-inner > .item > a > img {
  display: block;
  max-width: 100%;
  height: auto;
}
</style>

     <div class="page-title" style="background-color: rgb(1 2 217); ">
			<div class="grid-row">
				<h1 style="color: #000;">Civil Department



</h1>
				<nav class="bread-crumb">
					<a href="/">Home</a>
					<i class="fas fa-long-arrow-alt-right"></i>
				
					<a href="civil.php">Civil Department




</a>
				</nav>
			</div>
		</div>

		


<div class="row page-content">
    <div class="container clear-fix">
      <div class="grid-col-row">
        <div class="grid-col grid-col-8">
          <!-- main content -->
  
        
<h2>CIVIL Department Faculty List</h2>
          <hr>
      <table class="table table-bordered ">
   <tbody><tr>
    <th><b>S.No</b></th>
    <th><b>Name</b></th>
    <th><b>Registration Number</b></th>
    <th><b>Designation</b></th> 
    <th><b>Department</b></th>
    <th><b>Images</b></th>
   </tr>
   <tr>
    <td>1</td>
    
      <td>THUMMALA KUMAR SRUJAN</td> 
    <td>6054-160313-163145</td>
    <td>Head of the Department</td>
    <td>Civil Engineering</td>
    <td><img src="index_files/civil/civil_4.jpg" width="100%"></td>
   </tr>
   <tr>
    <td>2</td>
    <td>MOHAMMED ABDUL WAJID</td>
    <td>1638-150418-150326</td>
    <td>Assistant Professor</td>
    <td>Civil Engineering</td>
    <td><img src="index_files/civil/civil_2.jpg" width="100%"></td>
   </tr>
   <tr>
     <td>3</td>
    <td>BANDARU VENKATESH</td>
    <td>0208-160305-164938</td>
    <td>Assistant Professor</td>
    <td>Civil Engineering</td>
    <td><img src="index_files/civil/civil_3.jpg" width="100%"></td>
   </tr>
   <tr>
    <td>4</td>
  
    <td>MAGGIDI NAVEENKUMAR</td>
    <td>72150407-134110</td>
    <td>Assistant Professor</td>
    <td>Civil Engineering</td>
    <td><img src="index_files/civil/civil_1.jpg" width="100%"></td>
   </tr>
    <tr>
    <td>5</td>
    <td>SURESH KOTTALA</td>
    <td>5964-160314-155332</td>
    <td>Assistant Professor</td>
    <td>Civil Engineering</td>
    <td><img src="index_files/civil/civil_5.jpg" width="100%"></td>
    </tr>
    <tr>
     <td>6</td>
     <td>MOHAMMAD GOUSE KHAN</td>
     <td>4110-161220-120043</td>
     <td>Assistant Professor</td>
     <td>Civil Engineering</td>
     <td><img src="index_files/civil/civil_6.jpg" width="100%"></td>
    </tr>
    <tr>
     <td>7</td>
     <td>KUMAR DILIP JARUPULA</td>
     <td>3378-170105-141445</td>
     <td>Assistant Professor</td>
     <td>Civil Engineering</td>
     <td><img src="index_files/civil/civil_7.jpg" width="100%"></td>
    </tr>
    <tr>
     <td>8</td>
     <td>BAKOLLA LINGAM</td>
     <td>7744-170109-141853</td>
     <td>Assistant Professor</td>
     <td>Civil Engineering</td>
     <td><img src="index_files/civil/civil_8.jpg" width="100%"></td>
    </tr>
    <tr>
     <td>9</td>
     <td>MURUGESAN SURESH</td>
     <td>9036-171220-130635</td>
     <td>Assistant Professor</td>
     <td>Civil Engineering</td>
     <td><img src="index_files/civil/civil_9.jpg" width="100%"></td>
    </tr>
    <tr>
     <td>10</td>
     <td> SHANKREPPA SHANKREPPA</td>
     <td>2506-171226-112946</td>
     <td>Assistant Professor</td>
     <td>Civil Engineering</td>
     <td><img src="index_files/civil/civil_10.jpg" width="100%"></td>
    </tr>
    <tr>
     <td>11</td>
     <td>DEVUDUGOLLA KISHORE</td>
     <td>5075-190110-135108</td>
     <td>Assistant Professor</td>
     <td>Civil Engineering</td>
     <td><img src="index_files/civil/civil_11.jpg" width="100%"></td>
    </tr>
    <tr>
     <td>12</td>
     <td>RAHUL BATTU</td>
     <td>2702-190219-180204</td>
     <td>Assistant Professor</td>
     <td>Civil Engineering</td>
     <td><img src="index_files/civil/civil_12.jpg" width="100%"></td>
    </tr>
    <tr>
     <td>13</td>
     <td>SAI CHARAN RAJ SUMUKAM</td>
     <td>9729-190814-115636</td>
     <td>Assistant Professor</td>
     <td>Civil Engineering</td>
     <td><img src="index_files/civil/civil_13.jpg" width="100%"></td>
    </tr>
    <tr>
     <td>14</td>
     <td> TEJASWI KANDUNOORI</td>
     <td> 3350-190826-112857</td>
     <td>Assistant Professor</td>
     <td>Civil Engineering</td>
     <td><img src="index_files/civil/civil_14.jpg" width="100%"></td>
    </tr>
    <tr>
     <td>15</td>
     <td>SHINDHE SACHIN</td>
     <td>8888-170915-151248</td>
     <td>Assistant Professor</td>
     <td>Civil Engineering</td>
     <td><img src="index_files/civil/civil_15.jpg" width="100%"></td>
    </tr>
    <tr>
     <td>16</td>
     <td>RAMAVATH SHIRISHA</td>
     <td>8903-171023-153608</td>
     <td>Assistant Professor</td>
     <td>Civil Engineering</td>
     <td><img src="index_files/civil/civil_16.jpg" width="100%"></td>
    </tr>
     
    <!--   <tr>-->
    <!-- <td>19</td>-->
    <!--<td>SHIRISH KUMAR KYATHAM</td>-->
    <!--<td>ASST PROF</td>-->
    <!--<td>M.TECH</td>-->
    <!--</tr>-->
    <!-- <tr>-->
    <!-- <td>20</td>-->
    <!--<td>MAGGIDI NAVEENKUMAR</td>-->
    <!--<td>ASST PROF</td>-->
    <!--<td>M.TECH</td>-->
    <!--</tr>-->
    </tbody></table>




            <!-- / item -->
            <!-- item -->
        
       
          <!-- / main content -->
        
        </div>
        <!-- side bar -->
      <div class="grid-col grid-col-3">
          
          <h2>Quick Contact</h2>
      <hr>
          <form class="course_finder" action="#" method="post">
          <p><span class="your-name"><input type="text" name="name" value="" size="40" placeholder="Name" aria-invalid="false" required="" aria-required="true"></span>
            </p>
          <p><span class="your-email"><input type="text" name="phone" value="" size="40" placeholder="Phone" aria-invalid="false" required="" aria-required="true"></span> </p>
            <p class="form-row form-row-wide">
              <textarea class="input-text" rows="3" placeholder="Your Comment" name="message" id="calc_shipping_postcode"></textarea>
            </p>
            <p>
              <button type="submit" name="calc_shipping" value="1" class="cws-button border-radius alt small">Submit</button>
            </p>
          </form>
    <hr>
          
          
  
            <!-- carousel testimonials -->
          </div>
        <!-- / side bar -->
      </div>
    </div>
  </div>


<?php include 'footer.php'; ?>