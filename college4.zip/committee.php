
<?php include 'header.php'; ?>

	
          <style>


 .example-image-link{ padding:5px 10px; border:1px solid #ddd;	 background:#efeef; display:block;}

  .widget-event .date .day {
    background-color: #0102d9;
    color: #ffffff;
    font-size: 24px;
}

p{
  text-align:justify;
}
</style>

     <div class="page-title" style="  background-color: rgb(1 2 217);">
			<div class="grid-row">
				<h1 style="color: #000;">Committee</h1>
				<nav class="bread-crumb">
					<a href="/">Home</a>
					<i class="fas fa-long-arrow-alt-right"></i>
				
					<a href="committee.php">Committee</a>
				</nav>
			</div>
		</div>
<div class="page-content grid-row" style="height: 1370px;">
		<main>
			<div class="grid-col-row clear-fix" style="height: 1370px;">
			  
			  
			  




			  
				<div class="grid-col grid-col-3" >
					<div class="portfolio-item">
						<div class="picture">
							<div class="hover-effect"></div>
							<div class="link-cont">
							
								<a href="index_files/committee/G_Amrutha.jpg" class="fancy fa fa-search"></a>
								
							</div>
							<img style="width:100%;height:260px" src="index_files/committee/G_Amrutha.jpg" alt="">
						</div>
						<h3>Smt Dr.G. Amrutha Latha</h3>
						<p>Secretary (Ideal Educational Society)</p>
					</div>
					
				</div>
				




			  
				<div class="grid-col grid-col-3">
					<div class="portfolio-item">
						<div class="picture">
							<div class="hover-effect"></div>
							<div class="link-cont">
							
								<a href="index_files/committee/K_Narender_Reddy.jpg" class="fancy fa fa-search"></a>
								
							</div>
							<img style="width:100%;height:260px" src="index_files/committee/K_Narender_Reddy.jpg" data-at2x="index_files/committee/K_Narender_Reddy.jpg" alt="">
						</div>
						<h3>Sri.K.Narender Reddy</h3>
						<p>President(Ideal Educational Society)</p>
					</div>
					
				</div>
				




			  
				<div class="grid-col grid-col-3">
					<div class="portfolio-item">
						<div class="picture">
							<div class="hover-effect"></div>
							<div class="link-cont">
							
								<a href="index_files/committee/V_Prabha_Devi.jpg" class="fancy fa fa-search"></a>
								
							</div>
							<img style="width:100%;height:260px" src="index_files/committee/V_Prabha_Devi.jpg" data-at2x="index_files/committee/V_Prabha_Devi.jpg" alt="">
						</div>
						<h3>V PrabhaDevi</h3>
						<p>Vice President </p>
					</div>
					
				</div>
				




			  
				<div class="grid-col grid-col-3">
					<div class="portfolio-item">
						<div class="picture">
							<div class="hover-effect"></div>
							<div class="link-cont">
							
								<a href="index_files/committee/imageedit_14_6674401622.png" class="fancy fa fa-search"></a>
								
							</div>
							<img style="width:100%;height:260px" src="index_files/committee/imageedit_14_6674401622.png" data-at2x="index_files/committee/imageedit_14_6674401622.png" alt="">
						</div>
						<h3>Mr.M.Gangadhar</h3>
						<p>Vice President - I</p>
					</div>
					
				</div>
				




			  
				<div class="grid-col grid-col-3">
					<div class="portfolio-item">
						<div class="picture">
							<div class="hover-effect"></div>
							<div class="link-cont">
							
								<a href="index_files/committee/P_Sujatha.jpg" class="fancy fa fa-search"></a>
								
							</div>
							<img style="width:100%;height:260px" src="index_files/committee/P_Sujatha.jpg" data-at2x="index_files/committee/P_Sujatha.jpg" alt="">
						</div>
						<h3>P Sujatha</h3>
						<p>Addl Joint Secretary-I</p>
					</div>
					
				</div>
				




			  
				<div class="grid-col grid-col-3">
					<div class="portfolio-item">
						<div class="picture">
							<div class="hover-effect"></div>
							<div class="link-cont">
							
								<a href="index_files/committee/T_Vasantha.jpg" class="fancy fa fa-search"></a>
								
							</div>
							<img style="width:100%;height:260px" src="index_files/committee/T_Vasantha.jpg" data-at2x="index_files/committee/T_Vasantha.jpg" alt="">
						</div>
						<h3>T Vasantha</h3>
						<p>Treasurer</p>
					</div>
					
				</div>
				
				
			
			</div>
						

		</main>
	</div>

<script src="index_files/jquery.isotope.min.js"></script>
<?php include 'footer.php'; ?>