
<?php include 'header.php'; ?>

	
          <style>


 .example-image-link{ padding:5px 10px; border:1px solid #ddd;	 background:#efeef; display:block;}

  .widget-event .date .day {
    background-color: #0102d9;
    color: #ffffff;
    font-size: 24px;


}

p{
  text-align:justify;
}

.img-responsive,
.thumbnail > img,
.thumbnail a > img,
.carousel-inner > .item > img,
.carousel-inner > .item > a > img {
  display: block;
  max-width: 100%;
  height: auto;
}
</style>

     <div class="page-title" style="background-color: rgb(1 2 217); ">
			<div class="grid-row">
				<h1 style="color: #000;">Diploma Programs</h1>
				<nav class="bread-crumb">
					<a href="/">Home</a>
					<i class="fas fa-long-arrow-alt-right"></i>
				
					<a href="diploma-programs.php">Diploma Programs</a>
				</nav>
			</div>
		</div>

                
       <div class="row page-content" style="padding:30px;">
       <div class="col-md-3 col-sm-6 col-xs-12 bootCols"> <a href="diploma-detail.php"><h5 style="color: white; font-size: 1rem !important; position:absolute; top:30%; left:9%;"> DME - 60 </h5></a>
      </div>
      <div class="col-md-3 col-sm-6 col-xs-12 bootCols"><a href="diploma-detail.php"><h5 style="color: white; font-size: 1rem !important; position:absolute; top:35%; left:9%;"> DCE - 60</h5></a>
      </div>
      <div class="col-md-3 col-sm-6 col-xs-12 bootCols"><a href="diploma-detail.php"><h5 style="color: white; font-size: 1rem !important; position:absolute; top:35%; left:9%;"> DECE - 60</h5></a>
      </div>
      <div class="col-md-3 col-sm-6 col-xs-12 bootCols"><a href="diploma-detail.php"><h5 style="color: white; font-size: 1rem !important; position:absolute; top:35%; left:9%;"> DEEE - 60</h5></a>
      </div>
       <div class="col-md-3 col-sm-6 col-xs-12 bootCols"><a href="diploma-detail.php"><h5 style="color: white; font-size: 1rem !important; position:absolute; top:35%; left:9%;"> DCME - 60</h5></a>
      </div>
      <div class="col-md-3 col-sm-6 col-xs-12 bootCols"><a href="bsh.php"><h5 style="color: white; font-size: 1rem !important; position:absolute; top:35%; left:9%;"> BS &amp; H</h5></a>
      </div>
       
                  </div>
                   
                   
      </div>
		
	


<?php include 'footer.php'; ?>