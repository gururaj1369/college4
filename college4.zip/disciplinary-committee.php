
<?php include 'header.php'; ?>

	
          <style>


 .example-image-link{ padding:5px 10px; border:1px solid #ddd;	 background:#efeef; display:block;}

  .widget-event .date .day {
    background-color: #0102d9;
    color: #ffffff;
    font-size: 24px;


}

p{
  text-align:justify;
}

.img-responsive,
.thumbnail > img,
.thumbnail a > img,
.carousel-inner > .item > img,
.carousel-inner > .item > a > img {
  display: block;
  max-width: 100%;
  height: auto;
}
</style>

     <div class="page-title" style="background-color: rgb(1 2 217); ">
			<div class="grid-row">
				<h1 style="color: #000;">Disciplinary Committee






</h1>
				<nav class="bread-crumb">
					<a href="/">Home</a>
					<i class="fas fa-long-arrow-alt-right"></i>
				
					<a href="disciplinary-committee.php">Disciplinary Committee


</a>
				</nav>
			</div>
		</div>

		
<div class="row page-content grid-row">
    <main>
      <div class="grid-col-row clear-fix">
        
        
    


        
        <div class="grid-col grid-col-3">
          <div class="portfolio-item">
            <div class="picture">
              <div class="hover-effect"></div>
              <div class="link-cont">
              
                <a href="index_files/dc/sampath.png" class="fancy fa fa-search"></a>
                
              </div>
              <img style="width:100%;height:260px" src="index_files/dc/sampath.png" data-at2x="/uploads/2401/661368/sampath.png" alt="">
            </div>
            <h3>Dr. P. Sampath Rao  Principal</h3>
            <p>Chairman</p>
          </div>
          
        </div>
        


        
        <div class="grid-col grid-col-3">
          <div class="portfolio-item">
            <div class="picture">
              <div class="hover-effect"></div>
              <div class="link-cont">
              
                <a href="index_files/dc/samya.png" class="fancy fa fa-search"></a>
                
              </div>
              <img style="width:100%;height:260px" src="index_files/dc/samya.png" data-at2x="/uploads/2401/661377/samya.png" alt="">
            </div>
            <h3>Mr. B. Samya (HOD  Department of CSE</h3>
            <p>Secretary</p>
          </div>
          
        </div>
        


        
        <div class="grid-col grid-col-3">
          <div class="portfolio-item">
            <div class="picture">
              <div class="hover-effect"></div>
              <div class="link-cont">
              
                <a href="index_files/dc/Swapna.png" class="fancy fa fa-search"></a>
                
              </div>
              <img style="width:100%;height:260px" src="index_files/dc/Swapna.png" data-at2x="/uploads/2401/661370/Swapna.png" alt="">
            </div>
            <h3>Mrs. A. Swapna (HOD)  BS &amp; H Dept</h3>
            <p>Member</p>
          </div>
          
        </div>
        


        
        <div class="grid-col grid-col-3">
          <div class="portfolio-item">
            <div class="picture">
              <div class="hover-effect"></div>
              <div class="link-cont">
              
                <a href="index_files/dc/Srujan.png" class="fancy fa fa-search"></a>
                
              </div>
              <img style="width:100%;height:260px" src="index_files/dc/Srujan.png" data-at2x="/uploads/2401/661371/Srujan.png" alt="">
            </div>
            <h3>Mr. T. Srujan Kumar(HOD)(Department of Civil Engineering)</h3>
            <p>Member</p>
          </div>
          
        </div>
        


        
        <div class="grid-col grid-col-3">
          <div class="portfolio-item">
            <div class="picture">
              <div class="hover-effect"></div>
              <div class="link-cont">
              
                <a href="index_files/dc/shiva.png" class="fancy fa fa-search"></a>
                
              </div>
              <img style="width:100%;height:260px" src="index_files/dc/shiva.png" data-at2x="/uploads/2401/661372/shiva.png" alt="">
            </div>
            <h3>Mr. P. Shiva Kumar(HOD)Department of Mechanical Engineering</h3>
            <p>Member</p>
          </div>
          
        </div>
        


        
        <div class="grid-col grid-col-3">
          <div class="portfolio-item">
            <div class="picture">
              <div class="hover-effect"></div>
              <div class="link-cont">
              
                <a href="index_files/dc/Ravichandra.png" class="fancy fa fa-search"></a>
                
              </div>
              <img style="width:100%;height:260px" src="index_files/dc/Ravichandra.png" data-at2x="/uploads/2401/661373/Ravichandra.png" alt="">
            </div>
            <h3>Mr.J.Ravichandra Reddy</h3>
            <p>Member</p>
          </div>
          
        </div>
        


        
        <div class="grid-col grid-col-3">
          <div class="portfolio-item">
            <div class="picture">
              <div class="hover-effect"></div>
              <div class="link-cont">
              
                <a href="index_files/dc/patil.png" class="fancy fa fa-search"></a>
                
              </div>
              <img style="width:100%;height:260px" src="index_files/dc/patil.png" data-at2x="/uploads/2401/661374/patil.png" alt="">
            </div>
            <h3>Mr.Prakash Patil , (HOD)Department of ECE</h3>
            <p>Member</p>
          </div>
          
        </div>
        


        
        <div class="grid-col grid-col-3">
          <div class="portfolio-item">
            <div class="picture">
              <div class="hover-effect"></div>
              <div class="link-cont">
              
                <a href="index_files/dc/subhash.png" class="fancy fa fa-search"></a>
                
              </div>
              <img style="width:100%;height:260px" src="index_files/dc/subhash.png" data-at2x="/uploads/2401/661375/subhash.png" alt="">
            </div>
            <h3>Mr. Subhash Rathod (HOD)Department of EEE</h3>
            <p>Member</p>
          </div>
          
        </div>
        


        
        <div class="grid-col grid-col-3">
          <div class="portfolio-item">
            <div class="picture">
              <div class="hover-effect"></div>
              <div class="link-cont">
              
                <a href="index_files/dc/Rajender.png" class="fancy fa fa-search"></a>
                
              </div>
              <img style="width:100%;height:260px" src="index_files/dc/Rajender.png" data-at2x="/uploads/2401/661376/Rajender.png" alt="">
            </div>
            <h3>J.Rajender Dept.of ECE</h3>
            <p>Member</p>
          </div>
          
        </div>
        
        
        
      
      </div>
    
    </main>
  </div>


<?php include 'footer.php'; ?>