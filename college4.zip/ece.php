
<?php include 'header.php'; ?>

	
          <style>


 .example-image-link{ padding:5px 10px; border:1px solid #ddd;	 background:#efeef; display:block;}

  .widget-event .date .day {
    background-color: #0102d9;
    color: #ffffff;
    font-size: 24px;


}

p{
  text-align:justify;
}

.img-responsive,
.thumbnail > img,
.thumbnail a > img,
.carousel-inner > .item > img,
.carousel-inner > .item > a > img {
  display: block;
  max-width: 100%;
  height: auto;
}
</style>

     <div class="page-title" style="background-color: rgb(1 2 217); ">
			<div class="grid-row">
				<h1 style="color: #000;">ECE Department



</h1>
				<nav class="bread-crumb">
					<a href="/">Home</a>
					<i class="fas fa-long-arrow-alt-right"></i>
				
					<a href="ece.php">ECE Department




</a>
				</nav>
			</div>
		</div>

		


<div class="row page-content">
    <div class="container clear-fix">
      <div class="grid-col-row">
        <div class="grid-col grid-col-8">
          <!-- main content -->
  
        
<h2>ECE Department Faculty List</h2>
          <hr>
      <table class="table table-bordered ">
  <tbody><tr>
    <th><b>S.No</b></th>
    <th><b>Name</b></th>
    <th><b>Registration Number</b></th> 
    <th><b>Designation</b></th>
    <th><b>Department</b></th>
    <th><b>Images</b></th>
  </tr>
  <tr>
    <td>1</td>
    <td>PATIL PRAKASH</td> 
    <td>51150406-160616</td>
    <td>Head of the Department</td>
    <td>ECE</td>
    <td><img src="index_files/ece/ece_1.jpg" width="100%"></td>
    </tr>
    <tr>
    <td>2</td>
    <td>SWETHA GANGAM</td>
    <td>38150404-164420</td>
    <td>Assistant Professor</td>
    <td>ECE</td>
    <td><img src="index_files/ece/ece_2.jpg" width="100%"></td>
    </tr>
    <tr>
     <td>3</td>
    <td>KAMMARI SANDEEP KUMAR</td>
    <td>63150406-104737</td>
    <td>Assistant Professor</td>
    <td>ECE</td>
    <td><img src="index_files/ece/ece_3.jpg" width="100%"></td>
    </tr>
      <tr>
     <td>4</td>
    <td>BADAVATH RAVIKUMAR</td>
    <td>83150406-111758</td>
    <td>Assistant Professor</td>
    <td>ECE</td>
    <td><img src="index_files/ece/ece_4.jpg" width="100%"></td>
    </tr>
    <tr>
     <td>5</td>
    <td>BODDU PADMAVATHI</td>
    <td>57150406-124809</td>
    <td>Assistant Professor</td>
    <td>ECE</td>
    <td><img src="index_files/ece/ece_5.jpg" width="100%"></td>
    </tr>
     <tr>
     <td>6</td>
    <td>KUNDAN SRILAXMI</td>
    <td>05150406-193751</td>
    <td>Assistant Professor</td>
    <td>ECE</td>
    <td><img src="index_files/ece/ece_6.jpg" width="100%"></td>
    </tr>
      <tr>
     <td>7</td>
    <td>AZMEERA SUNDABAI</td>
    <td>45150406-204919</td>
    <td>Assistant Professor</td>
    <td>ECE</td>
    <td><img src="index_files/ece/ece_7.jpg" width="100%"></td>
    </tr>
      <tr>
     <td>8</td>
    <td>VIJAYAKRISHNA KANTHI</td>
    <td>1142-151231-141341</td>
    <td>Assistant Professor</td>
    <td>ECE</td>
    <td><img src="index_files/ece/ece_8.jpg" width="100%"></td>
    </tr>
      <tr>
     <td>9</td>
    <td>KARIPE MEENA</td>
    <td>2603-180426-150220</td>
    <td>Assistant Professor</td>
    <td>ECE</td>
    <td><img src="index_files/ece/ece_9.jpg" width="100%"></td>
    </tr>
      <tr>
     <td>10</td>
    <td>SAI KUMAR SALOOR</td>
    <td>9669-190502-144346</td>
    <td>Assistant Professor</td>
    <td>ECE</td>
    <td><img src="index_files/ece/ece_10.jpg" width="100%"></td>
    </tr>
      <tr>
     <td>11</td>
    <td>LAXMI LASINKAR</td>
    <td>2894-190823-135238</td>
    <td>Assistant Professor</td>
    <td>ECE</td>
    <td><img src="index_files/ece/ece_11.jpg" width="100%"></td>
    </tr>
      <tr>
     <td>12</td>
    <td>RAJENDER GANGONE</td>
    <td>6777-161208-142717</td>
    <td>Assistant Professor</td>
    <td>ECE</td>
    <td><img src="index_files/ece/ece_12.jpg" width="100%"></td>
    </tr>
     
    </tbody></table>




            <!-- / item -->
            <!-- item -->
        
       
          <!-- / main content -->
        
        </div>
        <!-- side bar -->
      <div class="grid-col grid-col-3">
          
          <h2>Quick Contact</h2>
      <hr>
          <form class="course_finder" action="#" method="post">
          <p><span class="your-name"><input type="text" name="name" value="" size="40" placeholder="Name" aria-invalid="false" required="" aria-required="true"></span>
            </p>
          <p><span class="your-email"><input type="text" name="phone" value="" size="40" placeholder="Phone" aria-invalid="false" required="" aria-required="true"></span> </p>
            <p class="form-row form-row-wide">
              <textarea class="input-text" rows="3" placeholder="Your Comment" name="message" id="calc_shipping_postcode"></textarea>
            </p>
            <p>
              <button type="submit" name="calc_shipping" value="1" class="cws-button border-radius alt small">Submit</button>
            </p>
          </form>
    <hr>
          
          
  
            <!-- carousel testimonials -->
          </div>
        <!-- / side bar -->
      </div>
    </div>
  </div>


<?php include 'footer.php'; ?>