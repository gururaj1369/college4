
<?php include 'header.php'; ?>

	
          <style>


 .example-image-link{ padding:5px 10px; border:1px solid #ddd;	 background:#efeef; display:block;}

  .widget-event .date .day {
    background-color: #0102d9;
    color: #ffffff;
    font-size: 24px;


}

p{
  text-align:justify;
}

.img-responsive,
.thumbnail > img,
.thumbnail a > img,
.carousel-inner > .item > img,
.carousel-inner > .item > a > img {
  display: block;
  max-width: 100%;
  height: auto;
}
</style>

     <div class="page-title" style="background-color: rgb(1 2 217); ">
			<div class="grid-row">
				<h1 style="color: #000;">EEE Department



</h1>
				<nav class="bread-crumb">
					<a href="/">Home</a>
					<i class="fas fa-long-arrow-alt-right"></i>
				
					<a href="eee.php">EEE Department




</a>
				</nav>
			</div>
		</div>

		


<div class="row page-content">
    <div class="container clear-fix">
      <div class="grid-col-row">
        <div class="grid-col grid-col-8">
          <!-- main content -->
  
        
<h2>EEE Department Faculty List</h2>
          <hr>
      <table class="table table-bordered ">
  <tbody><tr>
    <th><b>S.No</b></th>
    <th><b>Name</b></th>
    <th><b>Registration Number</b></th>
    <th><b>Designation</b></th> 
    <th><b>Department</b></th>
    <th><b>Images</b></th>
  </tr>
  <tr>
    <td>1</td>
    <td>R SUBASH RATHOD</td> 
    <td>08150406-132228</td>
    <td>Head of the Department</td>
    <td>EEE</td>
    <td><img src="index_files/eee/eee_1.jpg" width="100%"></td>
    </tr>
    <tr>
    <td>2</td>
    <td>AMGOTH SUSHEELA</td>
    <td>79150406-104125</td>
    <td>Assistant Professor</td>
    <td>EEE</td>
    <td><img src="index_files/eee/eee_2.jpg" width="100%"></td>
    </tr>
    <tr>
     <td>3</td>
    <td>MOHAMMED JAVEED</td>
    <td>0403-150416-160835</td>
    <td>Assistant Professor </td>
    <td>EEE</td>
    <td><img src="index_files/eee/eee_3.jpg" width="100%"></td>
    </tr>
      <tr>
     <td>4</td>
    <td>BHANOTH MOHAN</td>
    <td>3034-150417-171244</td>
    <td>Assistant Professor</td>
    <td>EEE</td>
    <td><img src="index_files/eee/eee_4.jpg" width="100%"></td>
    </tr>
     <tr>
     <td>5</td>
    <td>MITHUN KUMAR CHITEMALELI</td>
    <td>1911-160127-160044</td>
    <td>Assistant Professor</td>
    <td>EEE</td>
    <td><img src="index_files/eee/eee_5.jpg" width="100%"></td>
    </tr>
      <tr>
     <td>6</td>
    <td>CHOUL PRADEEP</td>
    <td>7853-160129-162514</td>
    <td>Assistant Professor</td>
    <td>EEE</td>
    <td><img src="index_files/eee/eee_6.jpg" width="100%"></td>
    </tr>
      <tr>
     <td>7</td>
    <td>CHANDRAKANTH BUNADI</td>
    <td>8919-161228-105757</td>
    <td>Assistant Professor</td>
    <td>EEE</td>
    <td><img src="index_files/eee/eee_7.jpg" width="100%"></td>
    </tr>
      <tr>
     <td>8</td>
    <td>AMARAGOMARA RAJITHA</td>
    <td>1821-180711-104436</td>
    <td>Assistant Professor</td>
    <td>EEE</td>
    <td><img src="index_files/eee/eee_8.jpg" width="100%"></td>
    </tr>
      <tr>
     <td>9</td>
    <td>MOUNIKA PADALA</td>
    <td>8655-190822-113320</td>
    <td>Assistant Professor</td>
    <td>EEE</td>
    <td><img src="index_files/eee/eee_9.jpg" width="100%"></td>
    </tr>
      <tr>
     <td>10</td>
    <td>NARESH ADICHARLA</td>
    <td>7439-190823-124651</td>
    <td>Assistant Professor</td>
    <td>EEE</td>
    <td><img src="index_files/eee/eee_10.jpg" width="100%"></td>
    </tr>
    </tbody></table>




            <!-- / item -->
            <!-- item -->
        
       
          <!-- / main content -->
        
        </div>
        <!-- side bar -->
      <div class="grid-col grid-col-3">
          
          <h2>Quick Contact</h2>
      <hr>
          <form class="course_finder" action="#" method="post">
          <p><span class="your-name"><input type="text" name="name" value="" size="40" placeholder="Name" aria-invalid="false" required="" aria-required="true"></span>
            </p>
          <p><span class="your-email"><input type="text" name="phone" value="" size="40" placeholder="Phone" aria-invalid="false" required="" aria-required="true"></span> </p>
            <p class="form-row form-row-wide">
              <textarea class="input-text" rows="3" placeholder="Your Comment" name="message" id="calc_shipping_postcode"></textarea>
            </p>
            <p>
              <button type="submit" name="calc_shipping" value="1" class="cws-button border-radius alt small">Submit</button>
            </p>
          </form>
    <hr>
          
          
  
            <!-- carousel testimonials -->
          </div>
        <!-- / side bar -->
      </div>
    </div>
  </div>


<?php include 'footer.php'; ?>