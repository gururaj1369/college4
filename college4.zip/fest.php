
<?php include 'header.php'; ?>

	
          <style>


 .example-image-link{ padding:5px 10px; border:1px solid #ddd;	 background:#efeef; display:block;}

  .widget-event .date .day {
    background-color: #0102d9;
    color: #ffffff;
    font-size: 24px;
}

p{
  text-align:justify;
}
</style>

     <div class="page-title" style="  background-color: rgb(1 2 217);">
			<div class="grid-row">
				<h1 style="color: #000;">Fest</h1>
				<nav class="bread-crumb">
					<a href="/">Home</a>
					<i class="fas fa-long-arrow-alt-right"></i>
				
					<a href="fest.php">Fest</a>
				</nav>
			</div>
		</div>
<div class="page_inner_container"> 
	 <div class="container"> 
	 <div class="row ">
		<div class="col-md-8">
			<div class="page_left mb-3">
			
			<div class="row ml-1 mr-2">
				<div class="col-md-12">
					
				</div>
			</div>
			
			
			<div class="row ml-1 mr-2">
				<div class="col-md-4 col-sm-6 col-6 mb-2  ">
	 
	 <a class="example-image-link" href="index_files/fest/fest1.jpg" data-lightbox="example-set" ><img class="example-image" src="index_files/fest/fest1.jpg" alt=""></a>
	
	
	
	</div>
					<div class="col-md-4 col-sm-6 col-6 mb-2  ">
	 
	 <a class="example-image-link" href="index_files/fest/fest2.jpg" ><img class="example-image" src="index_files/fest/fest2.jpg" alt=""></a>
	
	
	
	</div>
					<div class="col-md-4 col-sm-6 col-6 mb-2  ">
	 
	 <a class="example-image-link" href="index_files/fest/fest3.jpg"><img class="example-image" src="index_files/fest/fest3.jpg" alt=""></a>
	
	
	
	</div>
					<div class="col-md-4 col-sm-6 col-6 mb-2  ">
	 
	 <a class="example-image-link" href="index_files/fest/fest4.jpg" ><img class="example-image" src="index_files/fest/fest4.jpg" alt=""></a>
	
	
	
	</div>
					<div class="col-md-4 col-sm-6 col-6 mb-2  ">
	 
	 <a class="example-image-link" href="index_files/fest/fest6.jpg" ><img class="example-image" src="index_files/fest/fest6.jpg" alt=""></a>
	
	
	
	</div>

<div class="col-md-4 col-sm-6 col-6 mb-2  ">
	 
	 <a class="example-image-link" href="index_files/fest/fest7.jpg" ><img class="example-image" src="index_files/fest/fest7.jpg" alt=""></a>
	
	
	
	</div>
	<div class="col-md-4 col-sm-6 col-6 mb-2  ">
	 
	 <a class="example-image-link" href="index_files/fest/fest11.jpg" ><img class="example-image" src="index_files/fest/fest11.jpg" alt=""></a>
	
	
	
	</div>
	<div class="col-md-4 col-sm-6 col-6 mb-2  ">
	 
	 <a class="example-image-link" href="index_files/fest/fest12.jpg" ><img class="example-image" src="index_files/fest/fest12.jpg" alt=""></a>
	
	
	
	</div>
	<div class="col-md-4 col-sm-6 col-6 mb-2  ">
	 
	 <a class="example-image-link" href="index_files/fest/fest13.jpg" ><img class="example-image" src="index_files/fest/fest13.jpg" alt=""></a>
	
	
	
	</div>
	<div class="col-md-4 col-sm-6 col-6 mb-2  ">
	 
	 <a class="example-image-link" href="index_files/fest/fest14.jpg" ><img class="example-image" src="index_files/fest/fest14.jpg" alt=""></a>
	
	
	
	</div>
	<div class="col-md-4 col-sm-6 col-6 mb-2  ">
	 
	 <a class="example-image-link" href="index_files/fest/fest15.jpg" ><img class="example-image" src="index_files/fest/fest15.jpg" alt=""></a>
	
	
	
	</div>
	<div class="col-md-4 col-sm-6 col-6 mb-2  ">
	 
	 <a class="example-image-link" href="index_files/fest/fest16.jpg" ><img class="example-image" src="index_files/fest/fest16.jpg" alt=""></a>
	
	
	
	</div>
	<div class="col-md-4 col-sm-6 col-6 mb-2  ">
	 
	 <a class="example-image-link" href="index_files/fest/fest17.jpg" ><img class="example-image" src="index_files/fest/fest17.jpg" alt=""></a>
	
	
	
	</div>
	<div class="col-md-4 col-sm-6 col-6 mb-2  ">
	 
	 <a class="example-image-link" href="index_files/fest/fest18.jpg" ><img class="example-image" src="index_files/fest/fest18.jpg" alt=""></a>
	
	
	
	</div>
	<div class="col-md-4 col-sm-6 col-6 mb-2  ">
	 
	 <a class="example-image-link" href="index_files/fest/fest19.jpg" ><img class="example-image" src="index_files/fest/fest19.jpg" alt=""></a>
	
	
	
	</div>
	<div class="col-md-4 col-sm-6 col-6 mb-2  ">
	 
	 <a class="example-image-link" href="index_files/fest/fest20.jpg" ><img class="example-image" src="index_files/fest/fest20.jpg" alt=""></a>
	
	
	
	</div>
	<div class="col-md-4 col-sm-6 col-6 mb-2  ">
	 
	 <a class="example-image-link" href="index_files/fest/fest21.jpg" ><img class="example-image" src="index_files/fest/fest21.jpg" alt=""></a>
	
	
	
	</div>
	<div class="col-md-4 col-sm-6 col-6 mb-2  ">
	 
	 <a class="example-image-link" href="index_files/fest/fest22.jpg" ><img class="example-image" src="index_files/fest/fest22.jpg" alt=""></a>
	
	
	
	</div>
	<div class="col-md-4 col-sm-6 col-6 mb-2  ">
	 
	 <a class="example-image-link" href="index_files/fest/fest23.jpg" ><img class="example-image" src="index_files/fest/fest23.jpg" alt=""></a>
	
	
	
	</div>
	<div class="col-md-4 col-sm-6 col-6 mb-2  ">
	 
	 <a class="example-image-link" href="index_files/fest/fest24.jpg" ><img class="example-image" src="index_files/fest/fest24.jpg" alt=""></a>
	
	
	
	</div>
	<div class="col-md-4 col-sm-6 col-6 mb-2  ">
	 
	 <a class="example-image-link" href="index_files/fest/fest26.jpg" ><img class="example-image" src="index_files/fest/fest26.jpg" alt=""></a>
	
	
	
	</div>
	<div class="col-md-4 col-sm-6 col-6 mb-2  ">
	 
	 <a class="example-image-link" href="index_files/fest/fest27.jpg" ><img class="example-image" src="index_files/fest/fest27.jpg" alt=""></a>
	
	
	
	</div>















					 </div>
			
			 </div>
		</div>
		<div class="col-md-4">
			<div class="page_right ">
  
				
					<aside class="widget-event">
					
						<h2>Upcoming Events</h2>
						<article class="clear-fix">
							<div class="date"><div class="day">12</div><div class="month">Jan</div></div>
							<div class="event-description"><span>10:00am to 1:00pm</span><p>Graduate Open Day at the VREC. </p></div>
						</article>
						<article class="clear-fix">
							<div class="date"><div class="day">12</div><div class="month">Jan</div></div>
							<div class="event-description"><span>10:00am to 3:00pm</span><p>Visiting Artists: Giles Bailey.</p></div>
						</article>
						<article class="clear-fix">
							<div class="date"><div class="day">12</div><div class="month">Jan</div></div>
							<div class="event-description"><span>12:00am to 5:00pm</span><p>Workshop: Theories of the Image.</p></div>
						</article>
					</aside>
				
					<aside>
					<h2>Quick Contact</h2>
			
					<form class="course_finder" action="#" method="post">
					<p><span class="your-name"><input type="text" name="name" value="" size="40" placeholder="Name" aria-invalid="false" required="" aria-required="true"></span>
						</p>
					<p><span class="your-email"><input type="text" name="phone" value="" size="40" placeholder="Phone" aria-invalid="false" required="" aria-required="true"></span> </p>
						<p class="form-row form-row-wide">
							<textarea class="input-text" rows="3" placeholder="Your Comment" name="calc_shipping_postcode" id="calc_shipping_postcode"></textarea>
						</p>
						<p>
							<button type="submit" name="calc_shipping" value="1" class="cws-button border-radius alt small">Submit</button>
						</p>
					</form>
				</aside>
			</div>
		
				</div>
		<div class="clearfix"></div>
	 </div>
	 </div>
 </div>

<script src="index_files/jquery.isotope.min.js"></script>
<?php include 'footer.php'; ?>