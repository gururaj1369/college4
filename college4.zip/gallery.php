
<?php include 'header.php'; ?>

	
          <style>


 .example-image-link{ padding:5px 10px; border:1px solid #ddd;	 background:#efeef; display:block;}

  .widget-event .date .day {
    background-color: #0102d9;
    color: #ffffff;
    font-size: 24px;
}

p{
  text-align:justify;
}
</style>

     <div class="page-title" style="  background-color: rgb(1 2 217);">
			<div class="grid-row">
				<h1 style="color: #000;">Gallery</h1>
				<nav class="bread-crumb">
					<a href="/">Home</a>
					<i class="fas fa-long-arrow-alt-right"></i>
				
					<a href="gallery.php">Gallery</a>
				</nav>
			</div>
		</div>
<div class="page_inner_container"> 
	 <div class="container"> 
	 <div class="row ">
		<div class="col-md-8">
			<div class="page_left mb-3">
			
			<div class="row ml-1 mr-2">
				<div class="col-md-12">
					
				</div>
			</div>
			
			
			<div class="row ml-1 mr-2">
				<div class="col-md-4 col-sm-6 col-6 mb-2  ">
	 
	 <a class="example-image-link" href="index_files/college/001.jpg" data-lightbox="example-set" ><img class="example-image" src="index_files/college/001.jpg" alt=""></a>
	
	
	
	</div>
					<div class="col-md-4 col-sm-6 col-6 mb-2  ">
	 
	 <a class="example-image-link" href="index_files/college/002.jpg" ><img class="example-image" src="index_files/college/002.jpg" alt=""></a>
	
	
	
	</div>
					<div class="col-md-4 col-sm-6 col-6 mb-2  ">
	 
	 <a class="example-image-link" href="index_files/college/003.jpg"><img class="example-image" src="index_files/college/003.jpg" alt=""></a>
	
	
	
	</div>
					<div class="col-md-4 col-sm-6 col-6 mb-2  ">
	 
	 <a class="example-image-link" href="index_files/college/004.jpg" ><img class="example-image" src="index_files/college/004.jpg" alt=""></a>
	
	
	
	</div>

	<div class="col-md-4 col-sm-6 col-6 mb-2  ">
	 
	 <a class="example-image-link" href="index_files/college/005.jpg" ><img class="example-image" src="index_files/college/005.jpg" alt=""></a>
	
	
	
	</div>
					<div class="col-md-4 col-sm-6 col-6 mb-2  ">
	 
	 <a class="example-image-link" href="index_files/college/006.jpg" ><img class="example-image" src="index_files/college/006.jpg" alt=""></a>
	
	
	
	</div>

<div class="col-md-4 col-sm-6 col-6 mb-2  ">
	 
	 <a class="example-image-link" href="index_files/college/007.jpg" ><img class="example-image" src="index_files/college/007.jpg" alt=""></a>
	
	
	
	</div>
	<div class="col-md-4 col-sm-6 col-6 mb-2  ">
	 
	 <a class="example-image-link" href="index_files/college/008.jpg" ><img class="example-image" src="index_files/college/008.jpg" alt=""></a>
	
	
	
	</div>
	
	<div class="col-md-4 col-sm-6 col-6 mb-2  ">
	 
	 <a class="example-image-link" href="index_files/college/009.jpg" ><img class="example-image" src="index_files/college/009.jpg" alt=""></a>
	
	
	
	</div>
	<div class="col-md-4 col-sm-6 col-6 mb-2  ">
	 
	 <a class="example-image-link" href="index_files/college/010.jpg" ><img class="example-image" src="index_files/college/010.jpg" alt=""></a>
	
	
	
	</div>
	<div class="col-md-4 col-sm-6 col-6 mb-2  ">
	 
	 <a class="example-image-link" href="index_files/college/011.jpg" ><img class="example-image" src="index_files/college/011.jpg" alt=""></a>
	
	
	
	</div>
	<div class="col-md-4 col-sm-6 col-6 mb-2  ">
	 
	 <a class="example-image-link" href="index_files/college/012.jpg" ><img class="example-image" src="index_files/college/012.jpg" alt=""></a>
	
	
	
	</div>
	<div class="col-md-4 col-sm-6 col-6 mb-2  ">
	 
	 <a class="example-image-link" href="index_files/college/013.jpg" ><img class="example-image" src="index_files/college/013.jpg" alt=""></a>
	
	
	
	</div>
	<div class="col-md-4 col-sm-6 col-6 mb-2  ">
	 
	 <a class="example-image-link" href="index_files/college/014.jpg" ><img class="example-image" src="index_files/college/014.jpg" alt=""></a>
	
	
	
	</div>
	<div class="col-md-4 col-sm-6 col-6 mb-2  ">
	 
	 <a class="example-image-link" href="index_files/college/015.jpg" ><img class="example-image" src="index_files/college/015.jpg" alt=""></a>
	
	
	
	</div>
	<div class="col-md-4 col-sm-6 col-6 mb-2  ">
	 
	 <a class="example-image-link" href="index_files/college/016.jpg" ><img class="example-image" src="index_files/college/016.jpg" alt=""></a>
	
	
	
	</div>
	<div class="col-md-4 col-sm-6 col-6 mb-2  ">
	 
	 <a class="example-image-link" href="index_files/college/017.jpg" ><img class="example-image" src="index_files/college/017.jpg" alt=""></a>
	
	
	
	</div>
	<div class="col-md-4 col-sm-6 col-6 mb-2  ">
	 
	 <a class="example-image-link" href="index_files/college/018.jpg" ><img class="example-image" src="index_files/college/018.jpg" alt=""></a>
	
	
	
	</div>
		<div class="col-md-4 col-sm-6 col-6 mb-2  ">
	 
	 <a class="example-image-link" href="index_files/college/019.jpg" ><img class="example-image" src="index_files/college/019.jpg" alt=""></a>
	
	
	
	</div>
		<div class="col-md-4 col-sm-6 col-6 mb-2  ">
	 
	 <a class="example-image-link" href="index_files/college/020.jpg" ><img class="example-image" src="index_files/college/020.jpg" alt=""></a>
	
	
	
	</div>
		<div class="col-md-4 col-sm-6 col-6 mb-2  ">
	 
	 <a class="example-image-link" href="index_files/college/021.jpg" ><img class="example-image" src="index_files/college/021.jpg" alt=""></a>
	
	
	
	</div>
		<div class="col-md-4 col-sm-6 col-6 mb-2  ">
	 
	 <a class="example-image-link" href="index_files/college/022.jpg" ><img class="example-image" src="index_files/college/022.jpg" alt=""></a>
	
	
	
	</div>
		<div class="col-md-4 col-sm-6 col-6 mb-2  ">
	 
	 <a class="example-image-link" href="index_files/college/023.jpg" ><img class="example-image" src="index_files/college/023.jpg" alt=""></a>
	
	
	
	</div>
		<div class="col-md-4 col-sm-6 col-6 mb-2  ">
	 
	 <a class="example-image-link" href="index_files/college/024.jpg" ><img class="example-image" src="index_files/college/024.jpg" alt=""></a>
	
	
	
	</div>
		<div class="col-md-4 col-sm-6 col-6 mb-2  ">
	 
	 <a class="example-image-link" href="index_files/college/025.jpg" ><img class="example-image" src="index_files/college/025.jpg" alt=""></a>
	
	
	
	</div>
		<div class="col-md-4 col-sm-6 col-6 mb-2  ">
	 
	 <a class="example-image-link" href="index_files/college/026.jpg" ><img class="example-image" src="index_files/college/026.jpg" alt=""></a>
	
	
	
	</div>
		<div class="col-md-4 col-sm-6 col-6 mb-2  ">
	 
	 <a class="example-image-link" href="index_files/college/027.jpg" ><img class="example-image" src="index_files/college/027.jpg" alt=""></a>
	
	
	
	</div>
		<div class="col-md-4 col-sm-6 col-6 mb-2  ">
	 
	 <a class="example-image-link" href="index_files/college/028.jpg" ><img class="example-image" src="index_files/college/028.jpg" alt=""></a>
	
	
	
	</div>
		<div class="col-md-4 col-sm-6 col-6 mb-2  ">
	 
	 <a class="example-image-link" href="index_files/college/029.jpg" ><img class="example-image" src="index_files/college/029.jpg" alt=""></a>
	
	
	
	</div>
		<div class="col-md-4 col-sm-6 col-6 mb-2  ">
	 
	 <a class="example-image-link" href="index_files/college/030.jpg" ><img class="example-image" src="index_files/college/030.jpg" alt=""></a>
	
	
	
	</div>
		<div class="col-md-4 col-sm-6 col-6 mb-2  ">
	 
	 <a class="example-image-link" href="index_files/college/031.jpg" ><img class="example-image" src="index_files/college/031.jpg" alt=""></a>
	
	
	
	</div>
		<div class="col-md-4 col-sm-6 col-6 mb-2  ">
	 
	 <a class="example-image-link" href="index_files/college/032.jpg" ><img class="example-image" src="index_files/college/032.jpg" alt=""></a>
	
	
	
	</div>
		<div class="col-md-4 col-sm-6 col-6 mb-2  ">
	 
	 <a class="example-image-link" href="index_files/college/033.jpg" ><img class="example-image" src="index_files/college/033.jpg" alt=""></a>
	
	
	
	</div>
		<div class="col-md-4 col-sm-6 col-6 mb-2  ">
	 
	 <a class="example-image-link" href="index_files/college/034.jpg" ><img class="example-image" src="index_files/college/034.jpg" alt=""></a>
	
	
	
	</div>
		<div class="col-md-4 col-sm-6 col-6 mb-2  ">
	 
	 <a class="example-image-link" href="index_files/college/035.jpg" ><img class="example-image" src="index_files/college/035.jpg" alt=""></a>
	
	
	
	</div>
		<div class="col-md-4 col-sm-6 col-6 mb-2  ">
	 
	 <a class="example-image-link" href="index_files/college/036.jpg" ><img class="example-image" src="index_files/college/036.jpg" alt=""></a>
	
	
	
	</div>
		<div class="col-md-4 col-sm-6 col-6 mb-2  ">
	 
	 <a class="example-image-link" href="index_files/college/037.jpg" ><img class="example-image" src="index_files/college/037.jpg" alt=""></a>
	
	
	
	</div>
		<div class="col-md-4 col-sm-6 col-6 mb-2  ">
	 
	 <a class="example-image-link" href="index_files/college/038.jpg" ><img class="example-image" src="index_files/college/038.jpg" alt=""></a>
	
	
	
	</div>
		<div class="col-md-4 col-sm-6 col-6 mb-2  ">
	 
	 <a class="example-image-link" href="index_files/college/039.jpg" ><img class="example-image" src="index_files/college/039.jpg" alt=""></a>
	
	
	
	</div>
		<div class="col-md-4 col-sm-6 col-6 mb-2  ">
	 
	 <a class="example-image-link" href="index_files/college/040.jpg" ><img class="example-image" src="index_files/college/040.jpg" alt=""></a>
	
	
	
	</div>
		<div class="col-md-4 col-sm-6 col-6 mb-2  ">
	 
	 <a class="example-image-link" href="index_files/college/041.jpg" ><img class="example-image" src="index_files/college/041.jpg" alt=""></a>
	
	
	
	</div>
		<div class="col-md-4 col-sm-6 col-6 mb-2  ">
	 
	 <a class="example-image-link" href="index_files/college/042.jpg" ><img class="example-image" src="index_files/college/042.jpg" alt=""></a>
	
	
	
	</div>
		<div class="col-md-4 col-sm-6 col-6 mb-2  ">
	 
	 <a class="example-image-link" href="index_files/college/043.png" ><img class="example-image" src="index_files/college/043.png" alt="" ></a><p>principal</p>
	
	
	
	</div>
		<div class="col-md-4 col-sm-6 col-6 mb-2  ">
	 
	 <a class="example-image-link" href="index_files/college/044.jpg" ><img class="example-image" src="index_files/college/044.jpg" alt=""></a><p>secretary</p>
	
	
	
	</div>
		<div class="col-md-4 col-sm-6 col-6 mb-2  ">
	 
	 <a class="example-image-link" href="index_files/college/045.jpg" ><img class="example-image" src="index_files/college/045.jpg" alt=""></a><p>president</p>
	
	
	
	</div>
	





					 </div>
			
			 </div>
		</div>
		<div class="col-md-4">
			<div class="page_right ">
  
				
					<aside class="widget-event">
					
						<h2>Upcoming Events</h2>
						<article class="clear-fix">
							<div class="date"><div class="day">12</div><div class="month">Jan</div></div>
							<div class="event-description"><span>10:00am to 1:00pm</span><p>Graduate Open Day at the VREC. </p></div>
						</article>
						<article class="clear-fix">
							<div class="date"><div class="day">12</div><div class="month">Jan</div></div>
							<div class="event-description"><span>10:00am to 3:00pm</span><p>Visiting Artists: Giles Bailey.</p></div>
						</article>
						<article class="clear-fix">
							<div class="date"><div class="day">12</div><div class="month">Jan</div></div>
							<div class="event-description"><span>12:00am to 5:00pm</span><p>Workshop: Theories of the Image.</p></div>
						</article>
					</aside>
				
					<aside>
					<h2>Quick Contact</h2>
			
					<form class="course_finder" action="#" method="post">
					<p><span class="your-name"><input type="text" name="name" value="" size="40" placeholder="Name" aria-invalid="false" required="" aria-required="true"></span>
						</p>
					<p><span class="your-email"><input type="text" name="phone" value="" size="40" placeholder="Phone" aria-invalid="false" required="" aria-required="true"></span> </p>
						<p class="form-row form-row-wide">
							<textarea class="input-text" rows="3" placeholder="Your Comment" name="calc_shipping_postcode" id="calc_shipping_postcode"></textarea>
						</p>
						<p>
							<button type="submit" name="calc_shipping" value="1" class="cws-button border-radius alt small">Submit</button>
						</p>
					</form>
				</aside>
			</div>
		
				</div>
		<div class="clearfix"></div>
	 </div>
	 </div>
 </div>

<script src="index_files/jquery.isotope.min.js"></script>
<?php include 'footer.php'; ?>