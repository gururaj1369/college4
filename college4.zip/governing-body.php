
<?php include 'header.php'; ?>

	
          <style>


 .example-image-link{ padding:5px 10px; border:1px solid #ddd;	 background:#efeef; display:block;}

  .widget-event .date .day {
    background-color: #0102d9;
    color: #ffffff;
    font-size: 24px;


}

p{
  text-align:justify;
}

.img-responsive,
.thumbnail > img,
.thumbnail a > img,
.carousel-inner > .item > img,
.carousel-inner > .item > a > img {
  display: block;
  max-width: 100%;
  height: auto;
}
</style>

     <div class="page-title" style="background-color: rgb(1 2 217); ">
			<div class="grid-row">
				<h1 style="color: #000;">Governing Body




</h1>
				<nav class="bread-crumb">
					<a href="/">Home</a>
					<i class="fas fa-long-arrow-alt-right"></i>
				
					<a href="governing-body.php">Governing Body





</a>
				</nav>
			</div>
		</div>

		

<div class="row page-content grid-row">
    <main>
      <div class="grid-col-row clear-fix">
        
        
    


        
        <div class="grid-col grid-col-3">
          <div class="portfolio-item">
            <div class="picture">
              <div class="hover-effect"></div>
              <div class="link-cont">
              
                <a href="index_files/gbody/college_image_of_VCPN.png" class="fancy fa fa-search"></a>
                
              </div>
              <img style="width:100%;height:260px" src="index_files/gbody/college_image_of_VCPN.png" data-at2x="/uploads/2401/661356/college_image_of_VCPN.png" alt="">
            </div>
            <h3>Dr. G. Amrutha Latha</h3>
            <p>Chairman</p>
          </div>
          
        </div>
        


        
        <div class="grid-col grid-col-3">
          <div class="portfolio-item">
            <div class="picture">
              <div class="hover-effect"></div>
              <div class="link-cont">
              
                <a href="index_files/gbody/narender.png" class="fancy fa fa-search"></a>
                
              </div>
              <img style="width:100%;height:260px" src="index_files/gbody/narender.png" data-at2x="/uploads/2401/661357/narender.png" alt="">
            </div>
            <h3>K. Narender Reddy</h3>
            <p>Member to be nominated by Registered Society / Trust</p>
          </div>
          
        </div>
        


        
        <div class="grid-col grid-col-3">
          <div class="portfolio-item">
            <div class="picture">
              <div class="hover-effect"></div>
              <div class="link-cont">
              
                <a href="index_files/gbody/vasantha.png" class="fancy fa fa-search"></a>
                
              </div>
              <img style="width:100%;height:260px" src="index_files/gbody/vasantha.png" data-at2x="/uploads/2401/661358/vasantha.png" alt="">
            </div>
            <h3>T.Vasantha</h3>
            <p>Member to be nominated by Registered Society / Trust</p>
          </div>
          
        </div>
        


        
        <div class="grid-col grid-col-3">
          <div class="portfolio-item">
            <div class="picture">
              <div class="hover-effect"></div>
              <div class="link-cont">
              
                <a href="index_files/gbody/sujatha.png" class="fancy fa fa-search"></a>
                
              </div>
              <img style="width:100%;height:260px" src="index_files/gbody/sujatha.png" data-at2x="/uploads/2401/661359/sujatha.png" alt="">
            </div>
            <h3>P.Sujatha</h3>
            <p>Member to be nominated by Registered Society / Trust</p>
          </div>
          
        </div>
        


        
        <div class="grid-col grid-col-3">
          <div class="portfolio-item">
            <div class="picture">
              <div class="hover-effect"></div>
              <div class="link-cont">
              
                <a href="index_files/gbody/Prabhadevi.png" class="fancy fa fa-search"></a>
                
              </div>
              <img style="width:100%;height:260px" src="index_files/gbody/Prabhadevi.png" data-at2x="/uploads/2401/661360/Prabhadevi.png" alt="">
            </div>
            <h3>V.Prabhadevi</h3>
            <p>Member to be nominated by Registered Society / Trust</p>
          </div>
          
        </div>
        


        
        <div class="grid-col grid-col-3">
          <div class="portfolio-item">
            <div class="picture">
              <div class="hover-effect"></div>
              <div class="link-cont">
              
                <a href="index_files/gbody/vineel.png" class="fancy fa fa-search"></a>
                
              </div>
              <img style="width:100%;height:260px" src="index_files/gbody/vineel.png" data-at2x="/uploads/2401/661361/vineel.png" alt="">
            </div>
            <h3>Vineel Reddy</h3>
            <p>Eminent Professional</p>
          </div>
          
        </div>
        


        
        <div class="grid-col grid-col-3">
          <div class="portfolio-item">
            <div class="picture">
              <div class="hover-effect"></div>
              <div class="link-cont">
              
                <a href="index_files/gbody/varalakshmi.png" class="fancy fa fa-search"></a>
                
              </div>
              <img style="width:100%;height:260px" src="index_files/gbody/varalakshmi.png" data-at2x="/uploads/2401/661363/varalakshmi.png" alt="">
            </div>
            <h3>Varalakshmi Yallanti</h3>
            <p>Eminent Professional</p>
          </div>
          
        </div>
        


        
        <div class="grid-col grid-col-3">
          <div class="portfolio-item">
            <div class="picture">
              <div class="hover-effect"></div>
              <div class="link-cont">
              
                <a href="index_files/gbody/suresh.png" class="fancy fa fa-search"></a>
                
              </div>
              <img style="width:100%;height:260px" src="index_files/gbody/suresh.png" data-at2x="/uploads/2401/661364/suresh.png" alt="">
            </div>
            <h3>Dr. CH.Suresh</h3>
            <p>Academician</p>
          </div>
          
        </div>
        


        
        <div class="grid-col grid-col-3">
          <div class="portfolio-item">
            <div class="picture">
              <div class="hover-effect"></div>
              <div class="link-cont">
              
                <a href="index_files/gbody/sriram.png" class="fancy fa fa-search"></a>
                
              </div>
              <img style="width:100%;height:260px" src="index_files/gbody/sriram.png" data-at2x="/uploads/2401/661365/sriram.png" alt="">
            </div>
            <h3>Sriram</h3>
            <p>Academician</p>
          </div>
          
        </div>
        


        
        <div class="grid-col grid-col-3">
          <div class="portfolio-item">
            <div class="picture">
              <div class="hover-effect"></div>
              <div class="link-cont">
              
                <a href="index_files/gbody/manzoor.png" class="fancy fa fa-search"></a>
                
              </div>
              <img style="width:100%;height:260px" src="index_files/gbody/manzoor.png" data-at2x="/uploads/2401/661366/manzoor.png" alt="">
            </div>
            <h3>Dr. Md. Manzoor Hussain</h3>
            <p>University Nominee</p>
          </div>
          
        </div>
        


        
        <div class="grid-col grid-col-3">
          <div class="portfolio-item">
            <div class="picture">
              <div class="hover-effect"></div>
              <div class="link-cont">
              
                <a href="index_files/gbody/sampath.png" class="fancy fa fa-search"></a>
                
              </div>
              <img style="width:100%;height:260px" src="index_files/gbody/sampath.png" data-at2x="/uploads/2401/661367/sampath.png" alt="">
            </div>
            <h3>POLUSANI SAMPATH RAO</h3>
            <p>Member Secretary [Principal(ex-officio)]</p>
          </div>
          
        </div>
        
        
        
      
      </div>
    
    </main>
  </div>

<?php include 'footer.php'; ?>