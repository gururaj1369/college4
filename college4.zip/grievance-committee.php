
<?php include 'header.php'; ?>

	
          <style>


 .example-image-link{ padding:5px 10px; border:1px solid #ddd;	 background:#efeef; display:block;}

  .widget-event .date .day {
    background-color: #0102d9;
    color: #ffffff;
    font-size: 24px;


}

p{
  text-align:justify;
}

.img-responsive,
.thumbnail > img,
.thumbnail a > img,
.carousel-inner > .item > img,
.carousel-inner > .item > a > img {
  display: block;
  max-width: 100%;
  height: auto;
}
</style>

     <div class="page-title" style="background-color: rgb(1 2 217); ">
			<div class="grid-row">
				<h1 style="color: #000;">Reconstitute Grievance Redressed Committee

</h1>
				<nav class="bread-crumb">
					<a href="/">Home</a>
					<i class="fas fa-long-arrow-alt-right"></i>
				
					<a href="grievance-committee.php">Reconstitute Grievance Redressed Committee


</a>
				</nav>
			</div>
		</div>


<div class="row page-content grid-row">
    <main>
      <div class="grid-col-row clear-fix">
        
        
        <!-- removing this section-->
        
        <div class="text-center">
          <p class="text-center">Click here to get Grievance Document </p>
          <button class="btn btn-primary"><a href="index_files/GrievanceCell.PDF" style="color: #fff;" target="_blank">Grievance</a></button>
        </div>
       



        <!--<div class="grid-col grid-col-3">-->
        <!--  <div class="portfolio-item">-->
        <!--    <div class="picture">-->
        <!--      <div class="hover-effect"></div>-->
        <!--      <div class="link-cont">-->
              
        <!--        <a href="/uploads/2401/661174/image1.jpg" class="fancy fa fa-search"></a>-->
                
        <!--      </div>-->
        <!--      <img  style="width:100%;height:260px" src="/uploads/2401/661174/image1.jpg" data-at2x="/uploads/2401/661174/image1.jpg" alt>-->
        <!--    </div>-->
        <!--    <h3>Dr. P. Sampath Rao (Principal)</h3>-->
        <!--    <p>Chairman</p>-->
        <!--  </div>-->
          
        <!--</div>-->
        <!--



        <!--<div class="grid-col grid-col-3">-->
        <!--  <div class="portfolio-item">-->
        <!--    <div class="picture">-->
        <!--      <div class="hover-effect"></div>-->
        <!--      <div class="link-cont">-->
              
        <!--        <a href="/uploads/2401/661175/image2.jpg" class="fancy fa fa-search"></a>-->
                
        <!--      </div>-->
        <!--      <img  style="width:100%;height:260px" src="/uploads/2401/661175/image2.jpg" data-at2x="/uploads/2401/661175/image2.jpg" alt>-->
        <!--    </div>-->
        <!--    <h3>Mrs. P. Swapna ( Assistant Professor)</h3>-->
        <!--    <p>Secretary</p>-->
        <!--  </div>-->
          
        <!--</div>-->
        <!--



        <!--<div class="grid-col grid-col-3">-->
        <!--  <div class="portfolio-item">-->
        <!--    <div class="picture">-->
        <!--      <div class="hover-effect"></div>-->
        <!--      <div class="link-cont">-->
              
        <!--        <a href="/uploads/2401/661176/image3.jpg" class="fancy fa fa-search"></a>-->
                
        <!--      </div>-->
        <!--      <img  style="width:100%;height:260px" src="/uploads/2401/661176/image3.jpg" data-at2x="/uploads/2401/661176/image3.jpg" alt>-->
        <!--    </div>-->
        <!--    <h3>Mrs. A. Swapna (HOD) BS & H Dept.</h3>-->
        <!--    <p>Member</p>-->
        <!--  </div>-->
          
        <!--</div>-->
        <!--



        <!--<div class="grid-col grid-col-3">-->
        <!--  <div class="portfolio-item">-->
        <!--    <div class="picture">-->
        <!--      <div class="hover-effect"></div>-->
        <!--      <div class="link-cont">-->
              
        <!--        <a href="/uploads/2401/662363/mohan.jpg" class="fancy fa fa-search"></a>-->
                
        <!--      </div>-->
        <!--      <img  style="width:100%;height:260px" src="/uploads/2401/662363/mohan.jpg" data-at2x="/uploads/2401/662363/mohan.jpg" alt>-->
        <!--    </div>-->
        <!--    <h3>B.Mohan Vice-Principal Polytechnic</h3>-->
        <!--    <p>Member</p>-->
        <!--  </div>-->
          
        <!--</div>-->
        <!--



        <!--<div class="grid-col grid-col-3">-->
        <!--  <div class="portfolio-item">-->
        <!--    <div class="picture">-->
        <!--      <div class="hover-effect"></div>-->
        <!--      <div class="link-cont">-->
              
        <!--        <a href="/uploads/2401/661178/image10.jpg" class="fancy fa fa-search"></a>-->
                
        <!--      </div>-->
        <!--      <img  style="width:100%;height:260px" src="/uploads/2401/661178/image10.jpg" data-at2x="/uploads/2401/661178/image10.jpg" alt>-->
        <!--    </div>-->
        <!--    <h3>Mr. T. Srujan Kumar(HOD) <br/>  (Department of Civil Engieeering) </h3>-->
        <!--    <p>Member</p>-->
        <!--  </div>-->
          
        <!--</div>-->
        <!--



        <!--<div class="grid-col grid-col-3">-->
        <!--  <div class="portfolio-item">-->
        <!--    <div class="picture">-->
        <!--      <div class="hover-effect"></div>-->
        <!--      <div class="link-cont">-->
              
        <!--        <a href="/uploads/2401/661179/image5.jpg" class="fancy fa fa-search"></a>-->
                
        <!--      </div>-->
        <!--      <img  style="width:100%;height:260px" src="/uploads/2401/661179/image5.jpg" data-at2x="/uploads/2401/661179/image5.jpg" alt>-->
        <!--    </div>-->
        <!--    <h3>Mr. P. Shiva Kumar(HOD)<br/>  Department of Mechanical Engineering  </h3>-->
        <!--    <p>Member</p>-->
        <!--  </div>-->
          
        <!--</div>-->
        <!--



        <!--<div class="grid-col grid-col-3">-->
        <!--  <div class="portfolio-item">-->
        <!--    <div class="picture">-->
        <!--      <div class="hover-effect"></div>-->
        <!--      <div class="link-cont">-->
              
        <!--        <a href="/uploads/2401/661181/image4.jpg" class="fancy fa fa-search"></a>-->
                
        <!--      </div>-->
        <!--      <img  style="width:100%;height:260px" src="/uploads/2401/661181/image4.jpg" data-at2x="/uploads/2401/661181/image4.jpg" alt>-->
        <!--    </div>-->
        <!--    <h3>Mr. B. Samya (HOD) <br/> Department of CSE</h3>-->
        <!--    <p>Member</p>-->
        <!--  </div>-->
          
        <!--</div>-->
        <!--



        <!--<div class="grid-col grid-col-3">-->
        <!--  <div class="portfolio-item">-->
        <!--    <div class="picture">-->
        <!--      <div class="hover-effect"></div>-->
        <!--      <div class="link-cont">-->
              
        <!--        <a href="/uploads/2401/661187/patil.png" class="fancy fa fa-search"></a>-->
                
        <!--      </div>-->
        <!--      <img  style="width:100%;height:260px" src="/uploads/2401/661187/patil.png" data-at2x="/uploads/2401/661187/patil.png" alt>-->
        <!--    </div>-->
        <!--    <h3>Mr. Prakash Patil, (HOD) <BR/> Department of ECE</h3>-->
        <!--    <p>Member</p>-->
        <!--  </div>-->
          
        <!--</div>-->
        <!--



        <!--<div class="grid-col grid-col-3">-->
        <!--  <div class="portfolio-item">-->
        <!--    <div class="picture">-->
        <!--      <div class="hover-effect"></div>-->
        <!--      <div class="link-cont">-->
              
        <!--        <a href="/uploads/2401/661260/rathod.png" class="fancy fa fa-search"></a>-->
                
        <!--      </div>-->
        <!--      <img  style="width:100%;height:260px" src="/uploads/2401/661260/rathod.png" data-at2x="/uploads/2401/661260/rathod.png" alt>-->
        <!--    </div>-->
        <!--    <h3>Mr. Subhash Rathod (HOD) <BR/> Department of EEE</h3>-->
        <!--    <p>Member</p>-->
        <!--  </div>-->
          
        <!--</div>-->
        <!--



        <!--<div class="grid-col grid-col-3">-->
        <!--  <div class="portfolio-item">-->
        <!--    <div class="picture">-->
        <!--      <div class="hover-effect"></div>-->
        <!--      <div class="link-cont">-->
              
        <!--        <a href="/uploads/2401/661189/prashanthi.png" class="fancy fa fa-search"></a>-->
                
        <!--      </div>-->
        <!--      <img  style="width:100%;height:260px" src="/uploads/2401/661189/prashanthi.png" data-at2x="/uploads/2401/661189/prashanthi.png" alt>-->
        <!--    </div>-->
        <!--    <h3>B. Prasanthi (HOD) <BR/>Department of DCE)</h3>-->
        <!--    <p>Member</p>-->
        <!--  </div>-->
          
        <!--</div>-->
        <!--



        <!--<div class="grid-col grid-col-3">-->
        <!--  <div class="portfolio-item">-->
        <!--    <div class="picture">-->
        <!--      <div class="hover-effect"></div>-->
        <!--      <div class="link-cont">-->
              
        <!--        <a href="/uploads/2401/661190/chetan.png" class="fancy fa fa-search"></a>-->
                
        <!--      </div>-->
        <!--      <img  style="width:100%;height:260px" src="/uploads/2401/661190/chetan.png" data-at2x="/uploads/2401/661190/chetan.png" alt>-->
        <!--    </div>-->
        <!--    <h3>K. Chetan Kumar (Senior Facult  Dept. Of DEEE)</h3>-->
        <!--    <p>Member</p>-->
        <!--  </div>-->
          
        <!--</div>-->
        <!--



        <!--<div class="grid-col grid-col-3">-->
        <!--  <div class="portfolio-item">-->
        <!--    <div class="picture">-->
        <!--      <div class="hover-effect"></div>-->
        <!--      <div class="link-cont">-->
              
        <!--        <a href="/uploads/2401/661183/image11.jpg" class="fancy fa fa-search"></a>-->
                
        <!--      </div>-->
        <!--      <img  style="width:100%;height:260px" src="/uploads/2401/661183/image11.jpg" data-at2x="/uploads/2401/661183/image11.jpg" alt>-->
        <!--    </div>-->
        <!--    <h3>K. Sandeep (Department of DECE)</h3>-->
        <!--    <p>Member</p>-->
        <!--  </div>-->
          
        <!--</div>-->
        <!--



        <!--<div class="grid-col grid-col-3">-->
        <!--  <div class="portfolio-item">-->
        <!--    <div class="picture">-->
        <!--      <div class="hover-effect"></div>-->
        <!--      <div class="link-cont">-->
              
        <!--        <a href="/uploads/2401/661191/Priyanka.png" class="fancy fa fa-search"></a>-->
                
        <!--      </div>-->
        <!--      <img  style="width:100%;height:260px" src="/uploads/2401/661191/Priyanka.png" data-at2x="/uploads/2401/661191/Priyanka.png" alt>-->
        <!--    </div>-->
        <!--    <h3>Priyanka(HOD Dept.of DCME)</h3>-->
        <!--    <p>Member</p>-->
        <!--  </div>-->
          
        <!--</div>-->
        <!---->
        
        
      
      </div>
    
    </main>
  </div>


<?php include 'footer.php'; ?>