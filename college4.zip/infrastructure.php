
<?php include 'header.php'; ?>

	
          <style>


 .example-image-link{ padding:5px 10px; border:1px solid #ddd;	 background:#efeef; display:block;}

  .widget-event .date .day {
    background-color: #0102d9;
    color: #ffffff;
    font-size: 24px;


}

p{
  text-align:justify;
}

.img-responsive,
.thumbnail > img,
.thumbnail a > img,
.carousel-inner > .item > img,
.carousel-inner > .item > a > img {
  display: block;
  max-width: 100%;
  height: auto;
}
</style>

     <div class="page-title" style="background-color: rgb(1 2 217); ">
			<div class="grid-row">
				<h1 style="color: #000;">Infrastructure</h1>
				<nav class="bread-crumb">
					<a href="/">Home</a>
					<i class="fas fa-long-arrow-alt-right"></i>
				
					<a href="infrastructure.php">Infrastructure</a>
				</nav>
			</div>
		</div>




<div class="row page-content">
		<div class="container clear-fix">
			<div class="grid-col-row">
				<div class="grid-col grid-col-8">
					<!-- main content -->
					<main>
					
						<!-- item -->
						
						<h2>Our Infrastructure</h2>
					<ul>
<li>State-of-the-art Campus with good class rooms</li>
<li>Linguistic Labs</li>
<li>Seminar Theatre and Conferences Halls for Personality Development Programs</li>
<li>Cafeteria</li>
<li>The Institute library has nearly 8000 books and more than 5000 titles in the field of Engineering and Management.</li>
</ul>
<h3>Laboratories</h3>

<img src="index_files/workinfra.jpg" style="width:100%">
						<hr class="divider-color">

<h3> Libraries</h3>
<img src="index_files/lab.png" style="width:100%">





					
					
						
						<!-- / item -->
						<!-- item -->
				
					</main>
					<!-- / main content -->
				
				</div>
				<!-- side bar -->
			<div class="grid-col grid-col-3">
					
					<h2>Quick Contact</h2>
			
					<form class="course_finder" action="#" method="post">
					<p><span class="your-name"><input type="text" name="name" value="" size="40" placeholder="Name" aria-invalid="false" required="" aria-required="true"></span>
						</p>
					<p><span class="your-email"><input type="text" name="phone" value="" size="40" placeholder="Phone" aria-invalid="false" required="" aria-required="true"></span> </p>
						<p class="form-row form-row-wide">
							<textarea class="input-text" rows="3" placeholder="Your Comment" name="calc_shipping_postcode" id="calc_shipping_postcode"></textarea>
						</p>
						<p>
							<button type="submit" name="calc_shipping" value="1" class="cws-button border-radius alt small">Submit</button>
						</p>
					</form>
    <hr>
					
						<!-- carousel testimonials -->
						
				<!-- / side bar -->
			</div>
		</div>
	</div>
</div>
<?php include 'footer.php'; ?>