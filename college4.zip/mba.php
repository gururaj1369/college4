
<?php include 'header.php'; ?>

	
          <style>


 .example-image-link{ padding:5px 10px; border:1px solid #ddd;	 background:#efeef; display:block;}

  .widget-event .date .day {
    background-color: #0102d9;
    color: #ffffff;
    font-size: 24px;


}

p{
  text-align:justify;
}

.img-responsive,
.thumbnail > img,
.thumbnail a > img,
.carousel-inner > .item > img,
.carousel-inner > .item > a > img {
  display: block;
  max-width: 100%;
  height: auto;
}
</style>

     <div class="page-title" style="background-color: rgb(1 2 217); ">
			<div class="grid-row">
				<h1 style="color: #000;">MBA Department



</h1>
				<nav class="bread-crumb">
					<a href="/">Home</a>
					<i class="fas fa-long-arrow-alt-right"></i>
				
					<a href="mba.php">MBA Department




</a>
				</nav>
			</div>
		</div>

		


<div class="row page-content">
    <div class="container clear-fix">
      <div class="grid-col-row">
        <div class="grid-col grid-col-8">
          <!-- main content -->
  
        
<h2>MBA Department Faculty List</h2>
          <hr>
      

      <table class="table table-bordered ">
  <tbody><tr>
    <th><b>S.No</b></th>
    <th><b>Name</b></th>
    <th><b>Registration Number</b></th>
    <th><b>Designation</b></th> 
    <th><b>Department</b></th>
    <th><b>Image</b></th>
  </tr>
  <tr>
    <td>1</td>
    <td>LAKSHMANAN LAKSHMANAN</td> 
    <td>8784-170213-172950</td>
    <td> Head of the Department</td>
    <td>MBA</td>
    <td><img src="index_files/mba/re_Lakshmanan.jpg" width="100%"></td>
    </tr>
    <tr>
    <td>2</td>
    <td>RAJA PRADEEP DEVAL</td>
    <td>1233-161217-115116</td>
    <td>Assistant Professor</td>
    <td>MBA</td>
     <td><img src="index_files/mba/re_Raja_Pradeep.jpg" width="100%"></td>
    </tr>
    <tr>
     <td>3</td>
    <td>LATHA DODDIVENUKA</td>
    <td>9259-170916-150027</td>
    <td>Assistant Professor</td>
    <td>MBA</td>
    <td><img src="index_files/mba/re_Latha.jpg" width="100%"></td>
    </tr>
     <tr>
     <td>4</td>
    <td>BORRA MURALI</td>
    <td>4771-180711-155647</td>
    <td>Assistant Professor</td>
    <td>MBA</td>
    <td><img src="index_files/mba/re_murali.jpg" width="100%"></td>
    </tr>
      <tr>
     <td>5</td>
    <td>MARNI VINOD KUMAR</td>
    <td>8796-180820-115124</td>
    <td>Assistant Professor</td>
    <td>MBA</td>
    <td><img src="index_files/mba/mba_5.jpg" width="100%"></td>
    </tr>
    <tr>
     <td>6</td>
    <td>AAMANI GOPU</td>
    <td>3376-190504-213244</td>
    <td>Assistant Professor</td>
    <td>MBA</td>
    <td><img src="index_files/mba/mba_6.jpg" width="100%"></td>
    </tr>
      <tr>
     <td>7</td>
    <td>SALEHA AHMEDI</td>
    <td>9484-190504-222228</td>
    <td>Assistant Professor</td>
    <td>MBA</td>
    <td><img src="index_files/mba/mba_7.jpg" width="100%"></td>
    </tr>
      
    </tbody></table>




            <!-- / item -->
            <!-- item -->
        
       
          <!-- / main content -->
        
        </div>
        <!-- side bar -->
      <div class="grid-col grid-col-3">
          
          <h2>Quick Contact</h2>
      <hr>
          <form class="course_finder" action="#" method="post">
          <p><span class="your-name"><input type="text" name="name" value="" size="40" placeholder="Name" aria-invalid="false" required="" aria-required="true"></span>
            </p>
          <p><span class="your-email"><input type="text" name="phone" value="" size="40" placeholder="Phone" aria-invalid="false" required="" aria-required="true"></span> </p>
            <p class="form-row form-row-wide">
              <textarea class="input-text" rows="3" placeholder="Your Comment" name="message" id="calc_shipping_postcode"></textarea>
            </p>
            <p>
              <button type="submit" name="calc_shipping" value="1" class="cws-button border-radius alt small">Submit</button>
            </p>
          </form>
    <hr>
          
          
  
            <!-- carousel testimonials -->
          </div>
        <!-- / side bar -->
      </div>
    </div>
  </div>


<?php include 'footer.php'; ?>