
<?php include 'header.php'; ?>

	
          <style>


 .example-image-link{ padding:5px 10px; border:1px solid #ddd;	 background:#efeef; display:block;}

  .widget-event .date .day {
    background-color: #0102d9;
    color: #ffffff;
    font-size: 24px;


}

p{
  text-align:justify;
}

.img-responsive,
.thumbnail > img,
.thumbnail a > img,
.carousel-inner > .item > img,
.carousel-inner > .item > a > img {
  display: block;
  max-width: 100%;
  height: auto;
}
</style>

     <div class="page-title" style="background-color: rgb(1 2 217); ">
			<div class="grid-row">
				<h1 style="color: #000;">NCC Unit</h1>
				<nav class="bread-crumb">
					<a href="/">Home</a>
					<i class="fas fa-long-arrow-alt-right"></i>
				
					<a href="ncc.php">Ncc Unit</a>
				</nav>
			</div>
		</div>




<div class="row page-content">
		<div class="container clear-fix">
			<div class=" grid-col-row">
				<div class="grid-col grid-col-8">
					<!-- main content -->
					<main>
					<h2>NCC Unit</h2>
					<hr>
					<div class="col-md-3">
					  <img src="index_files/SANDEEP.jpg" style="width:100%">
				   <center><b> K.SANDEEP KUMAR</b></center>

					</div>
					
						<!-- item -->
						<div class="col-md-9">	
						
				<ul>

<li>
The NCC Unit was inaugurated on 16-11-2013 by the commanding officer of NCC 12 (A) battalion, Col. Y S Pathania  at Vijay Rural Engineering College. The NCC training inculcates the spirit of unity, patriotism and discipline….. 
</li><li>
Our College Boys and Girls take part in many social activities outside the college.
</li><li>
NCC helps to develop the character, discipline and patriotism among the students.
</li><li>
Regular blood donation camps and other social awareness programs are arranged in our college.
</li><li>
This unit helps to create the spirit of patriotism among the students. Ours is only college in the district that has setup separate NCC units for both boys and girls. These boys and girls take part in many social activities outside the college and become active participants in reducing services to the nation.
</li>
</ul>

</div>
					
		<hr>
<h2 class="welcome-text">NCC Activities </h2>
			
			  	<div class="grid-col grid-col-3">
					<div class="portfolio-item">
						<div class="picture">
							<div class="hover-effect"></div>
							<div class="link-cont">
							
								<a href="index_files/ncc-1.jpg" class="fancy fa fa-search"></a>
								
							</div>
							<img src="index_files/ncc-1.jpg" data-at2x="/ncc-1.jpg" style="height: 257px" alt="">
						</div>
					</div>
					
				</div>
				
				
				
					<div class="grid-col grid-col-3">
					<div class="portfolio-item">
						<div class="picture">
							<div class="hover-effect"></div>
							<div class="link-cont">
							
								<a href="index_files/ncc-2.jpg" class="fancy fa fa-search"></a>
								
							</div>
							<img src="index_files/ncc-2.jpg" data-at2x="/ncc-2.jpg" style="height: 257px" alt="">
						</div>
					</div>
					
				</div>
						
						<!-- / item -->
						<!-- item -->
				
					</main>
					<!-- / main content -->
				
				</div>
				<!-- side bar -->
			<div class="grid-col grid-col-3">
					
					<h2>Quick Contact</h2>
			<hr>
					<form class="course_finder" action="#" method="post">
					<p><span class="your-name"><input type="text" name="name" value="" size="40" placeholder="Name" aria-invalid="false" required="" aria-required="true"></span>
						</p>
					<p><span class="your-email"><input type="text" name="phone" value="" size="40" placeholder="Phone" aria-invalid="false" required="" aria-required="true"></span> </p>
						<p class="form-row form-row-wide">
							<textarea class="input-text" rows="3" placeholder="Your Comment" name="calc_shipping_postcode" id="calc_shipping_postcode"></textarea>
						</p>
						<p>
							<button type="submit" name="calc_shipping" value="1" class="cws-button border-radius alt small">Submit</button>
						</p>
					</form>
    <hr>
					
						<!-- carousel testimonials -->
						

	
						<!-- carousel testimonials -->
					</div>
				<!-- / side bar -->
			</div>
		</div>
	</div>
<?php include 'footer.php'; ?>