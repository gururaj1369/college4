
<?php include 'header.php'; ?>


     <div class="page-title" style="  background-color: rgb(1 2 217);">
			<div class="grid-row">
				<h1 style="color: #000;">Principal Profile</h1>
				<nav class="bread-crumb">
					<a href="/">Home</a>
					<i class="fas fa-long-arrow-alt-right"></i>
				
					<a href="principal-profile.php">Principal Profile</a>
				</nav>
			</div>
		</div>


<div class="page-content">
		<main>
			<section>
			  <div class="container">
				
					<div class="row">
					
						<div class="col-md-6">
							
								<!--<div class="gallery-item picture">-->
								<!--	<img src="/sir-11.jpg" data-at2x="/sir-11.jpg" alt>-->
								<!--</div>-->
							
								<!--<div class="gallery-item picture">-->
									<img src="index_files/p_sampath_kumar.png" alt="">
								<!--</div>-->
							
				
						</div>
					
						<div class="col-md-6">
							<h1>Principal Profile(Dr. P.SAMPATH RAO)</h1>
							<small>B.Tech(Mech), M.Tech ,Ph.D(Mech)</small>
							<br>
							<br>
							
						<b>Profile of Dr.P.SAMPATH RAO:</b>
<!--					<ol>-->
<!--<li> Doctor of Philosophy in Electronics & Communication Engineering (Digital Image Processing) from          -->
<!--    Bundelkhand University, Uttar Pradesh, in the Year 2008.</li>-->
<!--<li> Master of Engineering Instrumentation from Swami Ramanand Teerth Marathwada University, Nanded, in the   -->
<!--    year 2004.</li>-->
<!--<li> Bachelor of Engineering in Electronics & Instrumentation from Pune University, Shahada, in the year 1995.</li>-->
<!--</ol>-->
                <!--<p>Dr. Dr. P.SAMPATH RAO is Head of the department and professor in Mechanical Engg. He worked in the various positions as vice Principal and Training and Placement Officer. He has more than 26 years of teaching experience. He obtained his B.Tech (Mech) from Nagarjuna University Guntur 1988 , M.Tech from NIT (RECW) Warangal. He obtained is PhD from JNTUH College of Engineering, JNTUH, Hyderabad in the year 2015 . He published 25 International journals, one national journal and published his two papers in international conferences and 6 national conferences. He conducted a couple of short term courses, seminars, workshops and delivered few expert lectures. He is expert-->
                <!--at guiding projects for under graduate and post graduate students, guiding students for paper presentation, project exhibition and poster presentation.</p>-->
                
                <p>
                  
                  Dr. P.SAMPATH RAO is worked as Head of the department and professor in Mechanical Engg. He
worked in the various positions as vice Principal, Principal for Second shift Polytechnic,exam branch
incharge and Training and Placement Officer. He has more than 29 years of professional experience. He
obtained his B.Tech (Mech) from Nagarjuna University Guntur 1988 , M.Tech from NIT (RECW)
Warangal 1990. He obtained is PhD from JNTUH College of Engineering, JNTUH, Hyderabad in the
year 2015 . He published 39 International journals, 2 national journals and published his 03 papers in
international conferences and 06 national conferences. He conducted a couple of short term courses,
seminars, workshops and delivered few expert lectures. He is expert at guiding projects for under
graduate and post graduate students, guiding students for paper presentation, project exhibition and poster
presentation.
                  
                  
                </p>
                
                
						</div>
						</div>
							<br>
							<br>
					
						<div class="row">
						<div class="col-md-6 col-sm-12">
	<br>					  
<b>Professional Experience: 30 Years</b>
<div class="table-responsive"><table class="table table-bordered">
  <thead>
    <tr>
      <th><b>S.No</b></th>
      <th><b>Name of the Organization</b></th>
      <th><b>Position Held</b></th> 
      <th><b>Period</b></th>
      <th><b>Experience</b></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>1</td>
      <td>VIJAY RURAL ENGINEERING COLLEGE </td>
      <td>PRINCIPAL</td>
      <td>05-05-2018 TO TILL DATE</td>
      <td></td>
    </tr>
        <tr>
          <td>2</td>
      <td>VIJAY RURAL ENGINEERING COLLEGE</td>
      <td>PROFESSOR &amp; HOD</td>
      <td>01-10-2003 TO 04-05-2018</td>
      <td>14 YEAR 7 MONTHS</td>
      
    </tr>
    <tr>
          <td>3</td>
      <td>VIJAY RURAL ENGINEERING COLLEGE</td>
      <td>ASSOCIATE PROFESSOR</td>
      <td>19-01-1999 TO 30-09-2003</td>
      <td>4 YEAR 9 MONTHS</td>
      
    </tr>
    <tr>
      <td>4</td>
      <td>S.V.H. COLLEGE OF ENGINEERING, MACHILIPATNAM</td>
      <td>LECTURER</td>
      <td>08-10-1990 TO 18-01-1999</td>
      <td>8 YEARS 3 MONTHS</td>
    </tr>
  </tbody>
</table></div>


						</div>
						<div class="col-md-6 col-sm-12">
						  <b>Administrative Experience: 22 Years</b>

<ul>
<li>As Head of the Department in Vijay Rural Engineering College, Nizamabad from 1999 to 2018.</li>
<li>As Professor incharge of examinations in Vijay Rural Engineering College, Nizamabad, from 1999 to 2003.</li>
<li>As incharge Principal in Vijay Rural Engineering College, Nizamabad</li>
<li style="text-align:justify;">	Working as Principal for second shift polytechnic Vijay Rural Engineering College from sept.2009 to till date</li>
<li>Associating in all affiliation works of university, AICTE work for establishment of engineering colleges from 2000.</li>
<li>Looking after inspections by JNTUH &amp; AICTE from 2000</li>
<li>Supervising all college celebrations &amp; Anti-Raging activities.</li>
<li style="text-align:justify;">As Chief Superintendent of UG, PG exams , EAMCET &amp; PRITACET , GROUP-I &amp; IV etc. for 15 Years and Associate Regional co-ordinator for EAMCET in NIZAMABAD Dt. for 5years.</li>
</ul> 

<br>

						</div>
					</div>
					<div class="row">
					  <div class="col-md-12">
					    <b>Research Area/Specialization:</b><br>
<p>CRITICAL ANALYSIS OF COMPOSITE MATERIALS EXPOSED TO ENVIRONMENTAL AND INDUSTRIAL OPERATING CONDITIONS</p>
<ul>
  <li>International Journals: 39</li>
  <li>	National Journal: 02</li>
  <li>	International conferences:03</li>
  <li>	National conferences: 06</li>
</ul>
					  </div>
					</div>
				</div>
			</section>
		
		</main>
	</div>




<?php include 'footer.php'; ?>