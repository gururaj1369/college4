
<?php include 'header.php'; ?>

	
          <style>


 .example-image-link{ padding:5px 10px; border:1px solid #ddd;	 background:#efeef; display:block;}

  .widget-event .date .day {
    background-color: #0102d9;
    color: #ffffff;
    font-size: 24px;


}

p{
  text-align:justify;
}

.img-responsive,
.thumbnail > img,
.thumbnail a > img,
.carousel-inner > .item > img,
.carousel-inner > .item > a > img {
  display: block;
  max-width: 100%;
  height: auto;
}
</style>

     <div class="page-title" style="background-color: rgb(1 2 217); ">
			<div class="grid-row">
				<h1 style="color: #000;">Women Protection Cell







</h1>
				<nav class="bread-crumb">
					<a href="/">Home</a>
					<i class="fas fa-long-arrow-alt-right"></i>
				
					<a href="woman-protection-cell.php">Women Protection Cell



</a>
				</nav>
			</div>
		</div>



<div class="row page-content grid-row">
    <main>
      <div class="grid-col-row clear-fix">
        
        
       



        
        <div class="grid-col grid-col-3">
          <div class="portfolio-item">
            <div class="picture">
              <div class="hover-effect"></div>
              <div class="link-cont">
              
                <a href="index_files/wpc/image3.jpg" class="fancy fa fa-search"></a>
                
              </div>
              <img style="width:100%;height:260px" src="index_files/wpc/image3.jpg" data-at2x="/uploads/2401/661192/image3.jpg" alt="">
            </div>
            <h3>A.SWAPNA, Asst.Professor B.S&amp;H (H.O.D)</h3>
            <p>Member</p>
          </div>
          
        </div>
        



        
        <div class="grid-col grid-col-3">
          <div class="portfolio-item">
            <div class="picture">
              <div class="hover-effect"></div>
              <div class="link-cont">
              
                <a href="index_files/wpc/Rajitha.png" class="fancy fa fa-search"></a>
                
              </div>
              <img style="width:100%;height:260px" src="index_files/wpc/Rajitha.png" data-at2x="/uploads/2401/661193/Rajitha.png" alt="">
            </div>
            <h3>A.RAJITHA Asst Professor, EEE</h3>
            <p>Member</p>
          </div>
          
        </div>
        



        
        <div class="grid-col grid-col-3">
          <div class="portfolio-item">
            <div class="picture">
              <div class="hover-effect"></div>
              <div class="link-cont">
              
                <a href="index_files/wpc/sujani.png" class="fancy fa fa-search"></a>
                
              </div>
              <img style="width:100%;height:260px" src="index_files/wpc/sujani.png" data-at2x="/uploads/2401/661194/sujani.png" alt="">
            </div>
            <h3>B.SUJANI <br> Asst Professor,CSE</h3>
            <p>Member</p>
          </div>
          
        </div>
        



        
        <div class="grid-col grid-col-3">
          <div class="portfolio-item">
            <div class="picture">
              <div class="hover-effect"></div>
              <div class="link-cont">
              
                <a href="index_files/wpc/G.swetha.png" class="fancy fa fa-search"></a>
                
              </div>
              <img style="width:100%;height:260px" src="index_files/wpc/G.swetha.png" data-at2x="/uploads/2401/661195/G.swetha.png" alt="">
            </div>
            <h3>G.SWETHA,<br>  Asst Professor,ECE</h3>
            <p>Member</p>
          </div>
          
        </div>
        



        
        <div class="grid-col grid-col-3">
          <div class="portfolio-item">
            <div class="picture">
              <div class="hover-effect"></div>
              <div class="link-cont">
              
                <a href="index_files/wpc/P.swapna.png" class="fancy fa fa-search"></a>
                
              </div>
              <img style="width:100%;height:260px" src="index_files/wpc/P.swapna.png" data-at2x="/uploads/2401/661196/P.swapna.png" alt="">
            </div>
            <h3>P.SWAPNA,<br>Asst Professor,CSE</h3>
            <p>Member</p>
          </div>
          
        </div>
        



        
        <div class="grid-col grid-col-3">
          <div class="portfolio-item">
            <div class="picture">
              <div class="hover-effect"></div>
              <div class="link-cont">
              
                <a href="index_files/wpc/G.B.Shivaranjani.png" class="fancy fa fa-search"></a>
                
              </div>
              <img style="width:100%;height:260px" src="index_files/wpc/G.B.Shivaranjani.png" data-at2x="/uploads/2401/661197/G.B.Shivaranjani.png" alt="">
            </div>
            <h3>G.B.SHIVARANJANI  <br>Asst Professor, BS&amp;H</h3>
            <p>Member</p>
          </div>
          
        </div>
        



        
        <div class="grid-col grid-col-3">
          <div class="portfolio-item">
            <div class="picture">
              <div class="hover-effect"></div>
              <div class="link-cont">
              
                <a href="index_files/wpc/t.Saritha.png" class="fancy fa fa-search"></a>
                
              </div>
              <img style="width:100%;height:260px" src="index_files/wpc/t.Saritha.png" data-at2x="/uploads/2401/661198/t.Saritha.png" alt="">
            </div>
            <h3>T.SARITHA    <br> Senior Lecturer , DCE</h3>
            <p>Member</p>
          </div>
          
        </div>
        



        
        <div class="grid-col grid-col-3">
          <div class="portfolio-item">
            <div class="picture">
              <div class="hover-effect"></div>
              <div class="link-cont">
              
                <a href="index_files/wpc/s.gouthami.png" class="fancy fa fa-search"></a>
                
              </div>
              <img style="width:100%;height:260px" src="index_files/wpc/s.gouthami.png" data-at2x="/uploads/2401/661199/s.gouthami.png" alt="">
            </div>
            <h3>S.GOUTHAMI <br> Lecturer , DCE</h3>
            <p>Member</p>
          </div>
          
        </div>
        



        
        <div class="grid-col grid-col-3">
          <div class="portfolio-item">
            <div class="picture">
              <div class="hover-effect"></div>
              <div class="link-cont">
              
                <a href="index_files/wpc/Kamala.png" class="fancy fa fa-search"></a>
                
              </div>
              <img style="width:100%;height:260px" src="index_files/wpc/Kamala.png" data-at2x="/uploads/2401/661200/Kamala.png" alt="">
            </div>
            <h3>KAMALA, <br>Non Teaching staff</h3>
            <p>Member</p>
          </div>
          
        </div>
        
        
        
      
      </div>
    
    </main>
  </div>




<?php include 'footer.php'; ?>